/* NkamVa — Mes ressources (espace apprenant) : ressources achetées, statut de consultation */
(function(){
  var owned = [
    {slug:'guide-qa-checklist', viewed:true, last:"il y a 4 j", views:2},
    {slug:'architecture-logicielle-ddd', viewed:false, last:null, views:0}
  ];
  (window.NK_PURCHASES ? NK_PURCHASES.extraPurchased() : []).forEach(function(slug){
    if(!owned.some(function(o){ return o.slug===slug; })) owned.push({slug:slug, viewed:false, last:null, views:0});
  });
  var list = document.getElementById('mr-list');
  var tabs = document.querySelectorAll('#mr-tabs button');
  var vues = owned.filter(function(o){ return o.viewed; }).length;
  var aouvrir = owned.length - vues;
  document.getElementById('mr-s-acquises').textContent = owned.length;
  document.getElementById('mr-s-consultees').textContent = vues;
  document.getElementById('mr-s-aouvrir').textContent = aouvrir;
  document.getElementById('mr-n-all').textContent = owned.length;
  document.getElementById('mr-n-vues').textContent = vues;
  document.getElementById('mr-n-aouvrir').textContent = aouvrir;

  var joinedSlugs = ['qa-tests-logiciels','ingenierie-logicielle-afrique'];
  var commItems = [];
  joinedSlugs.forEach(function(slug){
    var c = window.NKCOMM && NKCOMM.bySlug(slug);
    var items = (window.NK_COMM_RES && NK_COMM_RES[slug]) || [];
    items.forEach(function(r){ commItems.push({r:r, c:c}); });
  });
  document.getElementById('mr-s-comm').textContent = commItems.length;

  var DOC_ICON = '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"></path>';
  function commCard(entry){
    var r = entry.r, c = entry.c;
    return '<div class="mr-card"><div class="mr-thumb" style="background:var(--green-t);color:var(--green-d)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+DOC_ICON+'</svg></div>'
      +'<div class="mr-tx"><span class="rc-type">'+r.type+'</span><h3>'+r.title+'</h3><p>'+(c?'<a href="Communaute apprenant.dc.html?c='+c.slug+'">'+c.name+'</a> · ':'')+r.desc+'</p></div>'
      +'<div class="mr-actions"><button class="btn btn-o btn-sm" data-act="consult" data-title="'+r.title+'" data-type="'+r.type+'" data-desc="'+r.desc+'" data-comm-name="'+(c?c.name:'')+'" data-comm-slug="'+(c?c.slug:'')+'">Consulter</button></div></div>';
  }
  var commList = document.getElementById('mr-comm-list');
  if(commList){
    commList.innerHTML = commItems.length ? commItems.map(commCard).join('') : '<p class="csub">Rejoignez une communauté pour débloquer ses ressources incluses.</p>';
  }

  // ---- modale de consultation ----
  var modal = document.getElementById('res-modal'), mcard = document.getElementById('res-modal-card');
  var CLOSE_X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"></path></svg>';
  function openResModal(html){ mcard.innerHTML = '<button class="ac-modal-close" id="res-modal-x">'+CLOSE_X+'</button>'+html; modal.classList.add('open'); }
  function closeResModal(){ modal.classList.remove('open'); }
  if(modal){
    document.getElementById('res-modal-backdrop').addEventListener('click', closeResModal);
    mcard.addEventListener('click', function(e){ if(e.target.closest('#res-modal-x')) closeResModal(); else if(e.target.closest('[data-act="dl"]')){ toast('Téléchargement lancé'); } });
    document.addEventListener('click', function(e){
      var b = e.target.closest('[data-act="consult"]'); if(!b) return;
      var d = b.dataset;
      openResModal('<h3>'+d.title+'</h3><p class="csub">'+(d.commName?'<a href="Communaute apprenant.dc.html?c='+d.commSlug+'">'+d.commName+'</a> · ':'')+d.type+'</p>'
        +'<span class="chip" style="margin:2px 0 18px">Inclus avec l\u2019abonnement</span>'
        +'<p style="font-size:14px;color:var(--ink2);line-height:1.6;margin:0 0 24px">'+d.desc+'</p>'
        +'<div class="ac-modal-actions"><button class="btn btn-p" data-act="dl">Télécharger</button></div>');
    });
  }

  function card(o){
    var r = NKAMVA.bySlug(o.slug);
    if(!r) return '';
    var meta = o.viewed ? ('Consultée '+o.last+' · '+o.views+' vue'+(o.views>1?'s':'')) : 'Non consultée';
    return '<div class="mr-card">'
      +'<div class="mr-thumb cover '+r.category.cover+'">'+NK_glyph(r.format)+'</div>'
      +'<div class="mr-tx"><h3><a href="Ma ressource.dc.html?r='+r.slug+'">'+r.title+'</a></h3>'
      +'<p>'+r.author.name+' · '+meta+'</p></div>'
      +'<div class="mr-actions"><a class="btn btn-p btn-sm" href="Ma ressource.dc.html?r='+r.slug+'">Ouvrir</a><a class="btn btn-o btn-sm" href="Ma ressource.dc.html?r='+r.slug+'">Voir la fiche</a></div></div>';
  }

  function empty(){
    return '<div class="empty"><div class="eic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/></svg></div><h3>Aucune ressource ici</h3><p>Les ressources que vous achetez apparaissent dans cet onglet.</p><a class="btn btn-o" href="Catalogue apprenant.dc.html">Parcourir le catalogue</a></div>';
  }

  function render(tab){
    var items = owned.filter(function(o){
      if(tab==='vues') return o.viewed;
      if(tab==='aouvrir') return !o.viewed;
      return true;
    });
    list.innerHTML = items.length ? items.map(card).join('') : empty();
  }

  tabs.forEach(function(btn){
    btn.addEventListener('click', function(){
      tabs.forEach(function(b){ b.classList.remove('on'); });
      btn.classList.add('on');
      render(btn.dataset.tab);
    });
  });

  render('all');
})();
