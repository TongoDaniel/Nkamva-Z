/* NkamVa — Mes achats (apprenant) : historique des paiements (ressources + abonnements communautés) */
(function(){
  var resourcePurchases = [
    {slug:'guide-qa-checklist', date:'14 juillet 2026', method:'Mobile Money — Orange Money'},
    {slug:'architecture-logicielle-ddd', date:'2 juillet 2026', method:'Carte bancaire'}
  ];
  var subscriptions = [
    {slug:'qa-tests-logiciels', date:'23 juillet 2026', method:'Mobile Money — MTN MoMo', status:'active'},
    {slug:'ingenierie-logicielle-afrique', date:'9 août 2026', method:'Carte bancaire', status:'active'}
  ];
  (window.NK_PURCHASES ? NK_PURCHASES.extraPurchased() : []).forEach(function(slug){
    if(!resourcePurchases.some(function(p){ return p.slug===slug; })) resourcePurchases.push({slug:slug, date:"aujourd'hui", method:'Paiement mobile'});
  });
  (window.NK_PURCHASES ? NK_PURCHASES.extraJoined() : []).forEach(function(slug){
    if(!subscriptions.some(function(s){ return s.slug===slug; })) subscriptions.push({slug:slug, date:"aujourd'hui", method:'Paiement mobile', status:'active'});
  });

  var VIDEO_ICON = '<path d="M4 5h13v14H4z"></path><path d="M17 10l4-3v10l-4-3"></path>';
  var DOC_ICON = '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"></path>';
  function icon(fmt){ return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+(fmt==='video'?VIDEO_ICON:DOC_ICON)+'</svg>'; }

  function resRow(p){
    var r = NKAMVA.bySlug(p.slug); if(!r) return '';
    return '<div class="mr-card"><div class="mr-thumb cover '+r.category.cover+'">'+icon(r.fmt)+'</div>'
      +'<div class="mr-tx"><h3><a href="Ma ressource.dc.html?r='+r.slug+'">'+r.title+'</a></h3><p>Achetée le '+p.date+' · '+p.method+'</p></div>'
      +'<div class="mr-actions" style="align-items:flex-end"><span class="price">'+NKAMVA.fmtPrice(r.price)+'<small>FCFA</small></span><button class="btn btn-o btn-sm" data-act="receipt-res" data-slug="'+r.slug+'">Reçu</button></div></div>';
  }
  function subRow(s){
    var c = NKCOMM.bySlug(s.slug); if(!c) return '';
    var cancelled = s.status==='cancelled';
    var right = cancelled
      ? '<span class="status-cancelled">Résilié</span><a class="btn btn-o btn-sm" data-act="manage" data-slug="'+s.slug+'" href="#">Réactiver</a>'
      : '<span class="price">'+NKAMVA.fmtPrice(c.price)+'<small>FCFA/mois</small></span><a class="btn btn-o btn-sm" data-act="manage" data-slug="'+s.slug+'" href="#">Gérer</a>';
    return '<div class="mr-card"><div class="mr-thumb" style="background:var(--line2);color:var(--ink2);font:700 15px var(--body)">'+c.author.initials+'</div>'
      +'<div class="mr-tx"><h3><a href="Communaute apprenant.dc.html?c='+c.slug+'">'+c.name+'</a></h3><p>'+(cancelled?'Accès jusqu\u2019au '+s.date:'Abonnement mensuel · prochain prélèvement le '+s.date+' · '+s.method)+'</p></div>'
      +'<div class="mr-actions" style="align-items:flex-end">'+right+'</div></div>';
  }

  function refreshStats(){
    var total = resourcePurchases.reduce(function(s,p){ var r=NKAMVA.bySlug(p.slug); return s+(r?r.price:0); },0)
      + subscriptions.filter(function(x){return x.status!=='cancelled';}).reduce(function(s,x){ var c=NKCOMM.bySlug(x.slug); return s+(c?c.price:0); },0);
    var activeSub = subscriptions.filter(function(x){return x.status!=='cancelled';}).length;
    document.getElementById('ac-s-total').textContent = NKAMVA.fmtPrice(total);
    document.getElementById('ac-s-res').textContent = resourcePurchases.length;
    document.getElementById('ac-s-sub').textContent = activeSub;
    document.getElementById('ac-n-all').textContent = resourcePurchases.length + subscriptions.length;
    document.getElementById('ac-n-res').textContent = resourcePurchases.length;
    document.getElementById('ac-n-sub').textContent = subscriptions.length;
  }
  refreshStats();

  var list = document.getElementById('ac-list');
  var tabs = document.querySelectorAll('#ac-tabs button');
  var curTab = 'all';
  function render(tab){
    curTab = tab || curTab;
    if(curTab==='res') list.innerHTML = resourcePurchases.map(resRow).join('');
    else if(curTab==='sub') list.innerHTML = subscriptions.map(subRow).join('');
    else list.innerHTML = resourcePurchases.map(resRow).join('') + subscriptions.map(subRow).join('');
  }
  tabs.forEach(function(btn){
    btn.addEventListener('click', function(){
      tabs.forEach(function(b){ b.classList.remove('on'); });
      btn.classList.add('on');
      render(btn.dataset.tab);
    });
  });
  render('all');

  // ---- modale de gestion d'abonnement ----
  var modal = document.getElementById('ac-modal'), card = document.getElementById('ac-modal-card');
  var CLOSE_X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"></path></svg>';
  function openModal(html){ card.innerHTML = '<button class="ac-modal-close" id="ac-modal-x">'+CLOSE_X+'</button>'+html; modal.classList.add('open'); }
  function closeModal(){ modal.classList.remove('open'); }
  document.getElementById('ac-modal-backdrop').addEventListener('click', closeModal);

  function manageView(s, c){
    return '<h3>'+c.name+'</h3><p class="csub">Animée par '+c.author.name+' · '+NKAMVA.fmtPrice(c.price)+' FCFA / mois</p>'
      +'<div class="ac-rows"><div class="rm"><span>Prochain prélèvement</span><span>'+s.date+'</span></div><div class="rm"><span>Moyen de paiement</span><span>'+s.method+'</span></div></div>'
      +'<div class="ac-modal-actions"><button class="btn btn-o" data-act="pay">Changer de moyen de paiement</button><button class="btn btn-dark" data-act="cancel">Annuler l\u2019abonnement</button></div>';
  }
  function confirmCancelView(s, c){
    return '<h3>Résilier l\u2019abonnement ?</h3><p class="csub">Vous garderez l\u2019accès à '+c.name+' jusqu\u2019au '+s.date+'. Aucun nouveau prélèvement ne sera effectué ensuite.</p>'
      +'<div class="ac-modal-actions"><button class="btn btn-dark" data-act="cancel-confirm">Oui, résilier</button><button class="btn btn-o" data-act="keep">Garder l\u2019abonnement</button></div>';
  }
  function receiptView(p, r){
    var orderId = 'NKV-'+r.slug.slice(0,4).toUpperCase()+'-'+p.date.replace(/[^0-9]/g,'').slice(0,6);
    return '<h3>Reçu de paiement</h3><p class="csub">'+r.title+'</p>'
      +'<div class="ac-rows"><div class="rm"><span>N\u00b0 de commande</span><span>'+orderId+'</span></div><div class="rm"><span>Date</span><span>'+p.date+'</span></div><div class="rm"><span>Moyen de paiement</span><span>'+p.method+'</span></div><div class="rm"><span>Montant</span><span>'+NKAMVA.fmtPrice(r.price)+' FCFA</span></div></div>'
      +'<div class="ac-modal-actions"><button class="btn btn-p" data-act="receipt-dl">Télécharger le PDF</button></div>';
  }

  list.addEventListener('click', function(e){
    var rec = e.target.closest('[data-act="receipt-res"]'); if(rec){
      var slug = rec.dataset.slug, r = NKAMVA.bySlug(slug), p = resourcePurchases.find(function(x){return x.slug===slug;});
      if(r && p){ openModal(receiptView(p, r)); }
      return;
    }
    var b = e.target.closest('[data-act="manage"]'); if(!b) return;
    e.preventDefault();
    var slug = b.dataset.slug, s = subscriptions.find(function(x){return x.slug===slug;}), c = NKCOMM.bySlug(slug);
    if(!s || !c) return;
    if(s.status==='cancelled'){
      s.status = 'active';
      render(); refreshStats();
      toast('Abonnement réactivé');
      return;
    }
    openModal(manageView(s, c));
    card.dataset.slug = slug;
  });

  card.addEventListener('click', function(e){
    if(e.target.closest('#ac-modal-x')){ closeModal(); return; }
    var act = e.target.closest('[data-act]'); if(!act) return;
    var slug = card.dataset.slug, s = subscriptions.find(function(x){return x.slug===slug;}), c = NKCOMM.bySlug(slug);
    if(act.dataset.act==='pay'){ toast('Gestion des moyens de paiement — écran hors du périmètre de cette refonte'); }
    else if(act.dataset.act==='receipt-dl'){ toast('Téléchargement du reçu (PDF) lancé'); }
    else if(act.dataset.act==='cancel'){ openModal(confirmCancelView(s, c)); }
    else if(act.dataset.act==='keep'){ closeModal(); }
    else if(act.dataset.act==='cancel-confirm'){
      s.status = 'cancelled';
      closeModal();
      render(); refreshStats();
      toast('Abonnement résilié — accès jusqu\u2019au '+s.date);
    }
  });
})();
