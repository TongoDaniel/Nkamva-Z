/* NkamVa — carte communauté (.cc) partagée listing & recommandations */
(function(){
  const HEART='<svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-9.8-9A5.6 5.6 0 0 1 12 6.3 5.6 5.6 0 0 1 21.8 12c-2.3 4.4-9.8 9-9.8 9z"/></svg>';
  window.commCard = function(c,i){
    const fav = window.NK_isFav ? window.NK_isFav('community',c.slug) : false;
    return '<article class="cc" data-rv style="--i:'+((i||0)%8)+'">'
      +'<div class="cband cv-'+c.cat+'"><div class="cav">'+c.author.initials+'</div><button class="fav'+(fav?' on':'')+'" data-slug="'+c.slug+'" data-kind="community" aria-pressed="'+(fav?'true':'false')+'" aria-label="Ajouter aux favoris">'+HEART+'</button></div>'
      +'<div class="cbd"><span class="chip '+c.category.chip+'">'+c.category.label+'</span>'
      +'<h3><a href="'+(window.NK_SPACE==='learner'?'Communaute apprenant.dc.html':'Communaute.dc.html')+'?c='+c.slug+'">'+c.name+'</a></h3>'
      +'<span class="canim">Animée par <b>'+c.author.name+'</b></span>'
      +'<span class="cn">'+c.members.toLocaleString('fr-FR')+' membre'+(c.members>1?'s':'')+'</span>'
      +'<div class="cft"><span class="cprice">'+NKAMVA.fmtPrice(c.price)+'<small>FCFA / mois</small></span>'
      +'<span class="btn btn-p btn-sm" style="pointer-events:none">Rejoindre</span></div>'
      +'</div></article>';
  };
})();
