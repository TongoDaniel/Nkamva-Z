/* NkamVa — lecteur de replay (apprenant) */
(function(){
  var ICON = {
    play:'<path d="M8 5v14l11-7z" fill="currentColor" stroke="none"></path>',
    pause:'<rect x="6" y="5" width="4" height="14" fill="currentColor" stroke="none" rx="1"></rect><rect x="14" y="5" width="4" height="14" fill="currentColor" stroke="none" rx="1"></rect>',
    vol:'<path d="M4 9v6h4l5 4V5L8 9H4Z" fill="currentColor" stroke="none"></path><path d="M16.3 8.7a5 5 0 0 1 0 6.6"></path><path d="M18.8 6.2a8.5 8.5 0 0 1 0 11.6"></path>',
    mute:'<path d="M4 9v6h4l5 4V5L8 9H4Z" fill="currentColor" stroke="none"></path><path d="M22 9l-6 6M16 9l6 6"></path>',
    fs:'<path d="M8 3H5a2 2 0 0 0-2 2v3"></path><path d="M16 3h3a2 2 0 0 1 2 2v3"></path><path d="M21 16v3a2 2 0 0 1-2 2h-3"></path><path d="M3 16v3a2 2 0 0 0 2 2h3"></path>',
    more:'<circle cx="12" cy="5" r="1.6" fill="currentColor" stroke="none"></circle><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"></circle><circle cx="12" cy="19" r="1.6" fill="currentColor" stroke="none"></circle>',
    dl:'<path d="M12 3v12"></path><path d="M7 10l5 5 5-5"></path><path d="M5 21h14"></path>',
    exit:'<path d="M15 3h3.5A2.5 2.5 0 0 1 21 5.5v13a2.5 2.5 0 0 1-2.5 2.5H15"></path><path d="M10 16l5-4-5-4"></path><path d="M15 12H3"></path>',
    clock:'<circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3.5 2"></path>',
    cal:'<rect x="3" y="5" width="18" height="16" rx="2"></rect><path d="M8 3v4M16 3v4M3 10h18"></path>',
    users:'<circle cx="9" cy="8" r="3.2"></circle><path d="M3.5 19c0-3 2.5-5 5.5-5s5.5 2 5.5 5"></path><path d="M15.5 5.5A3.2 3.2 0 0 1 17 11.6"></path><path d="M20.5 19c0-2.4-1.6-4.3-3.8-4.8"></path>',
    arrow:'<path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path>'
  };
  function svg(name,extra){ return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" '+(extra||'')+'>'+ICON[name]+'</svg>'; }
  function fmt(s){ s=Math.max(0,Math.round(s)); var m=Math.floor(s/60), r=s%60; return m+':'+(r<10?'0':'')+r; }

  var session = {
    status:'replay',
    title:'Concevoir un plan de test solide',
    community:'QA & Tests logiciels',
    communityHref:'Communaute apprenant.dc.html?c=qa-tests-logiciels',
    formateur:'Daniel Tongo',
    initials:'DT',
    role:'Lead QA & testeur',
    date:'16 juillet 2026',
    duration:2530,
    desc:"Daniel détaille la structure d'un plan de test efficace — priorisation des cas, checklists de non-régression — et répond aux questions posées en direct par la communauté."
  };

  var shell = document.getElementById('replay-shell');
  if(!shell) return;

  shell.innerHTML =
    '<div class="replay-top">'+
      '<div class="rid"><img class="mki" src="assets/img/mark.svg" alt="">'+
        '<div><div style="display:flex;align-items:center;gap:10px">'+
          '<span class="replay-badge'+(session.status==='live'?' live':'')+'">'+(session.status==='live'?'LIVE':'REPLAY')+'</span>'+
          '<h1>'+session.title+'</h1>'+
        '</div><p class="replay-sub">'+session.community+' · '+session.date+' · '+fmt(session.duration)+'</p></div>'+
      '</div>'+
      '<a class="replay-quit" href="Mes lives.dc.html">'+svg('exit')+'Quitter</a>'+
    '</div>'+
    '<div class="replay-grid">'+
      '<div class="replay-player">'+
        '<div class="replay-video" id="rv-video">'+
          '<button class="replay-play" id="rv-play" aria-label="Lecture">'+svg('play')+'</button>'+
          '<p class="ph-note">REPLAY · '+fmt(session.duration)+'</p>'+
        '</div>'+
        '<div class="replay-controls">'+
          '<button id="rc-play">'+svg('play')+'</button>'+
          '<span class="rc-time"><span id="rc-cur">0:00</span> / '+fmt(session.duration)+'</span>'+
          '<div class="rc-bar" id="rc-bar"><i id="rc-fill"></i></div>'+
          '<button id="rc-vol">'+svg('vol')+'</button>'+
          '<button class="rc-speed" id="rc-speed">1x</button>'+
          '<button id="rc-fs">'+svg('fs')+'</button>'+
          '<div class="rc-more-wrap" style="position:relative">'+
            '<button id="rc-more">'+svg('more')+'</button>'+
            '<div class="replay-more-menu" id="rc-menu">'+
              '<button data-act="dl">'+svg('dl')+'Télécharger</button>'+
              '<button data-act="speed">'+svg('clock')+'Vitesse de lecture</button>'+
              '<button data-act="pip">'+svg('fs')+'Image en incrustation</button>'+
            '</div>'+
          '</div>'+
        '</div>'+
      '</div>'+
      '<div class="replay-info">'+
        '<div><div class="replay-info-head">À PROPOS DE CETTE SESSION</div><h2>'+session.title+'</h2><p class="ri-desc">'+session.desc+'</p></div>'+
        '<a class="replay-formateur" href="Formateur.dc.html?id=dt"><span class="ava">'+session.initials+'</span><span><b>'+session.formateur+'</b><span>'+session.role+'</span></span></a>'+
        '<div class="replay-meta">'+
          '<div class="rm">'+svg('users')+session.community+'</div>'+
          '<div class="rm">'+svg('cal')+session.date+'</div>'+
          '<div class="rm">'+svg('clock')+fmt(session.duration)+' de rediffusion</div>'+
        '</div>'+
        '<div class="replay-notes-block"><div class="replay-info-head" style="margin-bottom:8px">MES NOTES</div><textarea id="rp-notes" placeholder="Prenez vos notes en regardant ce replay…"></textarea></div>'+
        '<a class="replay-cta" href="'+session.communityHref+'">Voir la communauté'+svg('arrow')+'</a>'+
      '</div>'+
    '</div>'+
    '<div class="replay-foot">'+
      '<span class="rf-meta">'+svg('clock')+'Disponible en replay pour les membres de la communauté</span>'+
      '<button class="replay-dl" id="rf-dl">'+svg('dl')+'Télécharger le replay (MP4)</button>'+
    '</div>';

  var duration = session.duration, cur = 0, playing = false, timer = null, muted = false;
  var speeds = [0.5,1,1.25,1.5,2], speedIdx = 1;
  var elBar = document.getElementById('rc-bar'), elFill = document.getElementById('rc-fill'), elCur = document.getElementById('rc-cur');
  var elVideo = document.getElementById('rv-video'), elMenu = document.getElementById('rc-menu'), elSpeed = document.getElementById('rc-speed');

  function paint(){
    elFill.style.width = (cur/duration*100)+'%';
    elCur.textContent = fmt(cur);
    var icon = playing ? svg('pause') : svg('play');
    document.getElementById('rc-play').innerHTML = icon;
    document.getElementById('rv-play').innerHTML = playing ? svg('pause') : svg('play');
  }
  function tick(){
    cur += 1 * speeds[speedIdx];
    if(cur >= duration){ cur = duration; togglePlay(false); }
    paint();
  }
  function togglePlay(on){
    playing = on;
    if(playing){
      if(cur >= duration) cur = 0;
      timer = setInterval(tick, 1000);
    } else {
      clearInterval(timer);
    }
    paint();
  }
  document.getElementById('rv-play').addEventListener('click', function(){ togglePlay(!playing); });
  document.getElementById('rc-play').addEventListener('click', function(){ togglePlay(!playing); });
  elBar.addEventListener('click', function(e){
    var r = elBar.getBoundingClientRect();
    cur = Math.min(duration, Math.max(0, (e.clientX - r.left) / r.width * duration));
    paint();
  });
  document.getElementById('rc-vol').addEventListener('click', function(){
    muted = !muted;
    this.innerHTML = muted ? svg('mute') : svg('vol');
    toast(muted ? 'Son coupé' : 'Son réactivé');
  });
  document.getElementById('rc-fs').addEventListener('click', function(){
    if(document.fullscreenElement){ document.exitFullscreen(); }
    else if(elVideo.requestFullscreen){ elVideo.requestFullscreen(); }
  });
  function cycleSpeed(){
    speedIdx = (speedIdx+1) % speeds.length;
    elSpeed.textContent = speeds[speedIdx]+'x';
    toast('Vitesse de lecture : '+speeds[speedIdx]+'x');
  }
  document.getElementById('rc-speed').addEventListener('click', cycleSpeed);
  document.getElementById('rc-more').addEventListener('click', function(e){
    if(e.target.closest('button[data-act]')) return;
    elMenu.classList.toggle('open');
  });
  elMenu.addEventListener('click', function(e){
    var b = e.target.closest('button[data-act]'); if(!b) return;
    e.stopPropagation();
    elMenu.classList.remove('open');
    if(b.dataset.act==='dl') { toast('Téléchargement du replay lancé'); }
    else if(b.dataset.act==='speed') { cycleSpeed(); }
    else if(b.dataset.act==='pip') { toast('Image en incrustation indisponible pour ce replay'); }
  });
  document.addEventListener('click', function(e){
    if(!e.target.closest('#rc-more')) elMenu.classList.remove('open');
  });
  document.getElementById('rf-dl').addEventListener('click', function(){ toast('Téléchargement du replay lancé'); });

  var notesKey = 'nk_live_notes';
  var notesEl = document.getElementById('rp-notes');
  notesEl.value = localStorage.getItem(notesKey) || '';
  notesEl.addEventListener('input', function(){ localStorage.setItem(notesKey, notesEl.value); });

  paint();
})();
