/* NkamVa — bascule des onglets Profil & paramètres */
(function(){
  var btns=Array.prototype.slice.call(document.querySelectorAll('.setnav [data-tab]'));
  var panels=Array.prototype.slice.call(document.querySelectorAll('.setpanel'));
  function activate(tab){
    btns.forEach(function(b){b.classList.toggle('on',b.dataset.tab===tab);});
    panels.forEach(function(p){p.classList.toggle('on',p.dataset.panel===tab);});
  }
  btns.forEach(function(b){
    b.addEventListener('click',function(){
      activate(b.dataset.tab);
      history.replaceState(null,'','#'+b.dataset.tab);
    });
  });
  var hash=(location.hash||'').replace('#','');
  if(hash && btns.some(function(b){return b.dataset.tab===hash;})) activate(hash);
})();
