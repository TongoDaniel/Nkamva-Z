/* NkamVa — fiche formateur : rend le profil depuis ?f=id */
(function(){
  const id = new URLSearchParams(location.search).get('f');
  const f = NKTRAIN.bySlug(id) || NKTRAIN.list[0];
  document.title = f.name + ' — NkamVa';
  const c = f.community;
  const P = NKAMVA.fmtPrice;

  document.getElementById('crumbtop').innerHTML =
    '<a href="'+(window.NK_SPACE==='learner'?'Formateurs apprenant.dc.html':'Formateurs.dc.html')+'">Formateurs</a><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg><span>'+f.name+'</span>';

  document.getElementById('chead').innerHTML =
    '<div class="chead2"><div class="cav2 tav2">'+f.initials+'</div><div><div class="tnamerow"><h1>'+f.name+'</h1><span class="status">Formateur certifié</span></div>'
    +'<span class="canim">'+f.role+' · '+f.city+'</span></div></div>';

  document.getElementById('cstats').innerHTML =
    '<div class="st"><b>'+f.resources+'</b><span>ressource'+(f.resources>1?'s':'')+' publiée'+(f.resources>1?'s':'')+'</span></div>'
    +'<div class="st"><b>'+f.students.toLocaleString('fr-FR')+'</b><span>apprenants formés</span></div>'
    +'<div class="st"><b>'+f.since+'</b><span>membre depuis</span></div>';

  const related = NKAMVA.resources.filter(r=>r.author.id===f.id);
  const resList = related.length ? '<div class="rgrid">'+related.map((r,i)=>rcCard(r,i)).join('')+'</div>'
    : '<div class="empty"><div class="eic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg></div><h3>Aucune ressource publiée</h3><p>'+f.name+' n\u2019a pas encore mis de ressource en vente à l\u2019unité.</p></div>';

  document.getElementById('cmain').innerHTML =
    '<section class="csec"><h2>À propos de '+f.name.split(' ')[0]+'</h2><p>'+f.bio+'</p></section>'
    +'<section class="csec"><h2>Ressources de '+f.name.split(' ')[0]+'</h2>'+resList+'</section>';

  const commHref = window.NK_SPACE==='learner' ? 'Communaute apprenant.dc.html?c='+c.slug : 'Communaute.dc.html?c='+c.slug;
  const joined = window.NK_SPACE==='learner' && window.NK_PURCHASES && NK_PURCHASES.isJoined(c.slug);
  const CK='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
  const commBox = joined
    ? '<div class="memberbox"><h4>Sa communauté</h4><div style="display:flex;align-items:center;gap:12px;margin-bottom:14px"><div class="cav" style="position:static">'+c.author.initials+'</div><div><div style="font-weight:700;font-size:14.5px">'+c.name+'</div><div style="color:var(--ink3);font-size:12.5px">'+c.members.toLocaleString('fr-FR')+' membres</div></div></div>'
      +'<div class="ownedtag" style="margin-bottom:12px">'+CK+'Vous êtes membre</div>'
      +'<a class="btn btn-p" style="width:100%" href="Messagerie.dc.html">Contacter le formateur</a></div>'
    : '<div class="memberbox"><h4>Sa communauté</h4><div style="display:flex;align-items:center;gap:12px;margin-bottom:14px"><div class="cav" style="position:static">'+c.author.initials+'</div><div><div style="font-weight:700;font-size:14.5px">'+c.name+'</div><div style="color:var(--ink3);font-size:12.5px">'+c.members.toLocaleString('fr-FR')+' membres</div></div></div>'
      +'<div style="font-family:var(--disp);font-weight:800;font-size:17px;margin-bottom:12px">'+P(c.price)+'<small style="font-size:12px;font-weight:700;color:var(--ink3)"> FCFA / mois</small></div>'
      +'<a class="btn btn-p" style="width:100%" href="'+commHref+'">Rejoindre la communauté</a></div>';

  document.getElementById('cside').innerHTML = commBox
    +'<div class="memberbox"><h4>Informations</h4><div style="display:flex;flex-direction:column;gap:10px;font-size:13.5px"><div style="display:flex;justify-content:space-between"><span style="color:var(--ink3)">Membre depuis</span><b>'+f.since+'</b></div><div style="display:flex;justify-content:space-between"><span style="color:var(--ink3)">Communauté</span><b>'+c.name+'</b></div><div style="display:flex;justify-content:space-between"><span style="color:var(--ink3)">Ville</span><b>'+f.city+'</b></div></div></div>';
})();
