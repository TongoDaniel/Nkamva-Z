/* NkamVa — Auth : interactions partagées */
(function(){
  function toast(msg){ window.toast ? window.toast(msg) : console.log(msg); }

  // password show/hide
  document.querySelectorAll('.eyebtn').forEach(function(btn){
    btn.addEventListener('click', function(){
      const inp = btn.parentElement.querySelector('input');
      const show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      btn.innerHTML = show
        ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"></path><circle cx="12" cy="12" r="3"></circle></svg>'
        : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.4 10.4 0 0 1 12 20c-6.5 0-10-7-10-7a18.6 18.6 0 0 1 4.2-5.2M9.9 4.2A10.7 10.7 0 0 1 12 4c6.5 0 10 7 10 7a18.7 18.7 0 0 1-2.2 3.1M14.1 14.1a3 3 0 1 1-4.2-4.2"></path><path d="M2 2l20 20"></path></svg>';
    });
  });

  // password strength
  document.querySelectorAll('.pwstrength-src').forEach(function(inp){
    const bars = document.querySelectorAll(inp.dataset.strength + ' i');
    inp.addEventListener('input', function(){
      let score = 0;
      if(inp.value.length >= 8) score++;
      if(/[A-Z]/.test(inp.value) && /[a-z]/.test(inp.value)) score++;
      if(/[0-9]/.test(inp.value) || /[^A-Za-z0-9]/.test(inp.value)) score++;
      bars.forEach(function(b,i){ b.className = i < score ? ('on'+score) : ''; });
    });
  });

  // role toggle cards
  document.querySelectorAll('.roletog').forEach(function(grp){
    grp.querySelectorAll('.ropt').forEach(function(opt){
      opt.addEventListener('click', function(){
        grp.querySelectorAll('.ropt').forEach(o=>o.classList.remove('on'));
        opt.classList.add('on');
      });
    });
  });

  // plan cards
  document.querySelectorAll('.planopts').forEach(function(grp){
    grp.querySelectorAll('.planopt').forEach(function(opt){
      opt.addEventListener('click', function(){
        grp.querySelectorAll('.planopt').forEach(o=>o.classList.remove('on'));
        opt.classList.add('on');
      });
    });
  });

  // code boxes auto-advance
  document.querySelectorAll('.codeboxes').forEach(function(grp){
    const boxes = [...grp.querySelectorAll('input')];
    boxes.forEach(function(box, i){
      box.addEventListener('input', function(){
        box.value = box.value.replace(/[^0-9]/g,'').slice(0,1);
        if(box.value && boxes[i+1]) boxes[i+1].focus();
      });
      box.addEventListener('keydown', function(e){
        if(e.key === 'Backspace' && !box.value && boxes[i-1]) boxes[i-1].focus();
      });
    });
  });

  // resend countdown
  document.querySelectorAll('[data-countdown]').forEach(function(el){
    let s = parseInt(el.dataset.countdown, 10);
    const render = () => { const m = Math.floor(s/60), sec = s%60; el.textContent = m+':'+String(sec).padStart(2,'0'); };
    render();
    const t = setInterval(function(){
      s--; if(s <= 0){ clearInterval(t); el.textContent = '00:00'; if(el.dataset.doneText) el.parentElement.querySelector('[data-resend]')?.removeAttribute('disabled'); return; }
      render();
    }, 1000);
  });

  // wizard navigation
  const wiz = document.querySelector('.wizshell');
  if(wiz){
    const panels = [...wiz.querySelectorAll('.wizpanel')];
    const steps = [...wiz.querySelectorAll('.step')];
    let cur = 0;
    function show(i){
      panels.forEach((p,idx)=> p.style.display = idx===i ? '' : 'none');
      steps.forEach((s,idx)=>{
        s.classList.toggle('active', idx===i);
        s.classList.toggle('done', idx<i);
        const sn = s.querySelector('.sn');
        sn.innerHTML = idx<i ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"></path></svg>' : String(idx+1);
      });
      cur = i;
    }
    show(0);
    wiz.querySelectorAll('[data-next]').forEach(btn=>btn.addEventListener('click', function(){
      if(cur < panels.length-1) show(cur+1);
    }));
    wiz.querySelectorAll('[data-back]').forEach(btn=>btn.addEventListener('click', function(){
      if(cur > 0) show(cur-1);
    }));
    const finalForm = wiz.querySelector('[data-final-submit]');
    if(finalForm) finalForm.addEventListener('submit', function(e){
      e.preventDefault();
      toast('Candidature envoyée — écran hors du périmètre de cette refonte');
    });
  }

  // simple form submits (sign in / sign up / forgot / reset)
  document.querySelectorAll('form[data-auth-submit]').forEach(function(f){
    f.addEventListener('submit', function(e){
      e.preventDefault();
      toast(f.dataset.authSubmit + ' — écran hors du périmètre de cette refonte');
    });
  });
})();
