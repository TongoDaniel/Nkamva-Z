/* NkamVa — Favoris : lit les favoris (ressources + communautés) depuis le stockage local */
(function(){
  function readList(kind){ try{ return JSON.parse(localStorage.getItem('nk_fav_'+kind+'s')||'[]'); }catch(e){ return []; } }
  const rGrid = document.getElementById('favres');
  const cGrid = document.getElementById('favcomm');
  const rCount = document.getElementById('favres-n');
  const cCount = document.getElementById('favcomm-n');

  function emptyState(kind){
    const label = kind==='resource' ? 'ressource' : 'communauté';
    const href = kind==='resource' ? (window.NK_SPACE==='learner'?'Catalogue apprenant.dc.html':'Catalogue.dc.html') : (window.NK_SPACE==='learner'?'Communautés apprenant.dc.html':'Communautes.dc.html');
    const cta = kind==='resource' ? 'Parcourir le catalogue' : 'Découvrir les communautés';
    return '<div class="empty" style="grid-column:1/-1"><div class="eic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-7.5-4.6-9.8-9A5.6 5.6 0 0 1 12 6.3 5.6 5.6 0 0 1 21.8 12c-2.3 4.4-9.8 9-9.8 9z"/></svg></div><h3>Aucune '+label+' en favoris</h3><p>Cliquez sur le c\u0153ur d\u2019une '+label+' pour la retrouver ici.</p><a class="btn btn-o" href="'+href+'">'+cta+'</a></div>';
  }

  function render(){
    const resources = readList('resource').map(s=>NKAMVA.bySlug(s)).filter(Boolean);
    const communities = readList('community').map(s=>NKCOMM.bySlug(s)).filter(Boolean);
    rCount.textContent = resources.length;
    cCount.textContent = communities.length;
    rGrid.className = resources.length ? 'rgrid' : '';
    rGrid.innerHTML = resources.length ? resources.map((r,i)=>rcCard(r,i)).join('') : emptyState('resource');
    cGrid.className = communities.length ? 'cgrid' : '';
    cGrid.innerHTML = communities.length ? communities.map((c,i)=>commCard(c,i)).join('') : emptyState('community');
  }
  render();

  document.addEventListener('click', function(e){
    const f = e.target.closest('.fav'); if(!f) return;
    setTimeout(function(){
      if(!f.classList.contains('on')){
        const card = f.closest('.rc, .cc');
        if(card){ card.style.transition='opacity .25s'; card.style.opacity='0'; setTimeout(render, 260); }
      }
    }, 0);
  });
})();
