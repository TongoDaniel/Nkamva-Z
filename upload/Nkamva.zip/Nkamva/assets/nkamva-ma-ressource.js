/* NkamVa — Ma ressource (espace apprenant) : détail d'une ressource déjà acquise, depuis ?r=slug */
(function(){
  const slug = new URLSearchParams(location.search).get('r');
  const r = NKAMVA.bySlug(slug) || NKAMVA.resources[0];
  document.title = r.title + ' — NkamVa';

  const CK='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
  const PLAY='<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M8 5v14l11-7z"/></svg>';
  const PAUSE='<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>';
  const DOC_BIG='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/><path d="M9 7h7M9 11h7M9 15h4"/></svg>';

  const progressKey = 'nk_progress_'+r.slug;
  function loadDone(){ try{ const l=JSON.parse(localStorage.getItem(progressKey)); return Array.isArray(l)?l:[]; }catch(e){ return []; } }
  let done = loadDone();
  function saveDone(){ localStorage.setItem(progressKey, JSON.stringify(done)); }
  function lessonKey(i,j){ return i+'-'+j; }

  const learn = r.learn.map(l=>'<li><span class="ck">'+CK+'</span>'+l+'</li>').join('');
  const curr = r.curriculum.map((m,i)=>{
    const lessons=[];
    for(let j=0;j<m.lessons;j++){
      const isVid = r.fmt==='video';
      const key = lessonKey(i,j);
      const watched = done.indexOf(key)!==-1;
      const ic = watched ? '<span class="lesson-ck">'+CK+'</span>' : (isVid?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M10 9l5 3-5 3z" fill="currentColor" stroke="none"/></svg>'
        :'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5"/></svg>');
      const d = isVid ? (6+((i*3+j)%9))+' min' : (2+((i+j)%4))+' pages';
      const title = m.title.split(',')[0].toLowerCase();
      lessons.push('<div class="lesson'+(watched?' watched':'')+'" data-mod="'+i+'" data-lesson="'+j+'" data-title="Leçon '+(j+1)+' — '+title+'" role="button" tabindex="0">'+ic+'Leçon '+(j+1)+' — '+title+'<span class="dur">'+d+'</span></div>');
    }
    return '<div class="qa'+(i===0?' open':'')+'"><button class="q" type="button">'+m.title
      +'<span class="modmeta"><span>'+m.lessons+' leçons</span><span class="x"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></span></button>'
      +'<div class="a"><div class="ain">'+lessons.join('')+'</div></div></div>';
  }).join('');

  const a=r.author;
  document.getElementById('ficheroot').innerHTML =
    '<nav class="crumb"><a href="Mes ressources.dc.html">Mes ressources</a><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg><span>'+r.title+'</span></nav>'
    +'<div class="dhead"><span class="chip '+r.category.chip+'">'+r.category.label+'</span><h1>'+r.title+'</h1>'
      +'<div class="dmeta"><span class="it"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>'+r.students.toLocaleString('fr-FR')+' apprenants</span>'
      +'<span class="sep"></span><span class="it"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>'+r.lang+'</span></div></div>'
    +'<div class="dhero"><div class="cover '+r.category.cover+'">'+NK_glyph(r.format)
      +(r.fmt==='video'?'<button class="playbtn" aria-label="Lecture"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button><span class="prevtag">'+r.format.label+' · '+r.meta+'</span>':'<span class="prevtag">'+r.format.label+' · '+r.meta+'</span>')+'</div></div>'
    +'<div class="lecteur-panel" id="lecteur" style="display:none"></div>'
    +'<section class="dsec"><h2>À propos de cette ressource</h2><p>'+r.blurb+'</p></section>'
    +'<section class="dsec"><h2>Ce que vous apprendrez</h2><ul class="learn">'+learn+'</ul></section>'
    +'<section class="dsec curr"><h2>'+(r.fmt==='video'?'Programme':'Contenu')+'</h2><div class="currsum"><span>'+r.curriculum.length+' modules</span><span>'+r.lessonsTotal+' '+(r.fmt==='video'?'leçons':'sections')+'</span><span>'+r.meta+'</span></div>'+curr+'</section>'
    +'<section class="dsec"><h2>Votre formateur</h2><div class="authcard"><div class="big">'+a.initials+'</div><div><h3>'+a.name+'</h3><p class="role">'+a.role+' · '+a.city+'</p><div class="astats"><span><b>'+a.students.toLocaleString('fr-FR')+'</b> apprenants</span><span><b>'+a.resources+'</b> ressources</span></div></div><p class="bio">'+a.bio+'</p></div></section>';

  function totalLessons(){ let n=0; r.curriculum.forEach(m=>n+=m.lessons); return n; }
  function firstUnwatched(){
    for(let i=0;i<r.curriculum.length;i++) for(let j=0;j<r.curriculum[i].lessons;j++) if(done.indexOf(lessonKey(i,j))===-1) return {i,j};
    return {i:0,j:0};
  }
  function openBtnLabel(){
    const n = done.length;
    if(n===0) return 'Ouvrir la ressource';
    if(n>=totalLessons()) return 'Revoir la ressource';
    return 'Reprendre la ressource';
  }

  const isFav = window.NK_isFav && NK_isFav('resource', r.slug);
  function paintBuybox(){
    document.getElementById('buybox').innerHTML =
      '<div class="bcover"><div class="cover '+r.category.cover+'"><span class="type">'+r.format.label.toUpperCase()+' · '+r.meta.toUpperCase()+'</span>'+NK_glyph(r.format)+'</div></div>'
      +'<div class="bd"><div class="pr"><span class="ownedtag">'+CK+'Ressource déjà acquise</span></div>'
      +(done.length ? '<p class="csub" style="margin:-8px 0 14px">'+done.length+'/'+totalLessons()+' leçons vues</p>' : '')
      +'<button class="btn btn-p btn-lg" id="open-btn">'+openBtnLabel()+'</button>'
      +'<button class="favfull btn btn-o'+(isFav?' on':'')+'" data-slug="'+r.slug+'" data-kind="resource" aria-pressed="'+(isFav?'true':'false')+'"><svg viewBox="0 0 24 24" fill="'+(isFav?'currentColor':'none')+'" stroke="currentColor" stroke-width="2"><path d="M12 21s-7.5-4.6-9.8-9A5.6 5.6 0 0 1 12 6.3 5.6 5.6 0 0 1 21.8 12c-2.3 4.4-9.8 9-9.8 9z"/></svg><span>'+(isFav?'Dans vos favoris':'Ajouter aux favoris')+'</span></button>'
      +'<div class="guarantee"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>Accès permanent, sur mobile comme sur ordinateur</div></div>';
  }
  paintBuybox();

  document.querySelector('.curr').addEventListener('click',e=>{
    const lesson = e.target.closest('.lesson');
    if(lesson){ openLesson(parseInt(lesson.dataset.mod,10), parseInt(lesson.dataset.lesson,10), lesson.dataset.title); return; }
    const q=e.target.closest('.q');if(!q)return;
    const qa=q.parentElement,a2=qa.querySelector('.a'),open=qa.classList.toggle('open');
    a2.style.maxHeight=open?a2.querySelector('.ain').scrollHeight+'px':0;
  });
  function openFirst(){var f=document.querySelector('.curr .qa.open .a');if(f)f.style.maxHeight=f.querySelector('.ain').scrollHeight+'px';}
  if(document.body.classList.contains('is-ready'))openFirst();
  else{var iv=setInterval(function(){if(document.body.classList.contains('is-ready')){clearInterval(iv);openFirst();}},80);}

  // ---- lecteur ----
  const panel = document.getElementById('lecteur');
  let playTimer = null;
  function markWatched(i,j){
    const key = lessonKey(i,j);
    if(done.indexOf(key)===-1){ done.push(key); saveDone(); }
    const row = document.querySelector('.lesson[data-mod="'+i+'"][data-lesson="'+j+'"]');
    if(row && !row.classList.contains('watched')){ row.classList.add('watched'); row.querySelector('svg,.lesson-ck')?.remove(); row.insertAdjacentHTML('afterbegin','<span class="lesson-ck">'+CK+'</span>'); }
    paintBuybox();
  }
  function openLesson(i,j,title){
    clearInterval(playTimer);
    panel.style.display = 'block';
    if(r.fmt==='video'){
      let playing = true, pct = 0;
      panel.innerHTML = '<div class="lec-video"><button class="lec-play">'+PAUSE+'</button><p class="ph-note">'+title+'</p></div>'
        +'<div class="lec-bar"><i style="width:0%"></i></div>'
        +'<div class="lec-foot"><span>'+title+'</span><button class="lec-close">Fermer</button></div>';
      const bar = panel.querySelector('.lec-bar i'), btn = panel.querySelector('.lec-play');
      playTimer = setInterval(()=>{
        if(!playing) return;
        pct += 100/14;
        if(pct>=100){ pct=100; clearInterval(playTimer); markWatched(i,j); }
        bar.style.width = pct+'%';
      }, 1000);
      btn.addEventListener('click', ()=>{ playing=!playing; btn.innerHTML = playing?PAUSE:PLAY; });
    } else {
      panel.innerHTML = '<div class="lec-doc">'+DOC_BIG+'<p>'+title+'</p></div>'
        +'<div class="lec-foot"><button class="btn btn-p btn-sm lec-mark">Marquer comme lue</button><button class="btn btn-o btn-sm lec-dl">Télécharger</button><button class="lec-close">Fermer</button></div>';
      panel.querySelector('.lec-mark').addEventListener('click', ()=>markWatched(i,j));
      panel.querySelector('.lec-dl').addEventListener('click', ()=>toast('Téléchargement lancé'));
    }
    panel.querySelector('.lec-close').addEventListener('click', ()=>{ clearInterval(playTimer); panel.style.display='none'; panel.innerHTML=''; });
    window.scrollTo({top: panel.getBoundingClientRect().top + window.scrollY - 90, behavior:'smooth'});
  }

  document.getElementById('buybox').addEventListener('click',function(e){
    if(e.target.closest('#open-btn')){ const f = firstUnwatched(); const row = document.querySelector('.lesson[data-mod="'+f.i+'"][data-lesson="'+f.j+'"]'); const title = row ? row.dataset.title : 'Leçon 1'; const qa = row ? row.closest('.qa') : null; if(qa && !qa.classList.contains('open')){ qa.classList.add('open'); const ai=qa.querySelector('.a'); ai.style.maxHeight=ai.querySelector('.ain').scrollHeight+'px'; } openLesson(f.i,f.j,title); return; }
    const f=e.target.closest('.favfull');if(!f)return;
    const on=!f.classList.contains('on');
    f.classList.toggle('on',on);
    f.setAttribute('aria-pressed',on);
    f.querySelector('span').textContent=on?'Dans vos favoris':'Ajouter aux favoris';
    f.querySelector('svg').setAttribute('fill',on?'currentColor':'none');
    const key='nk_fav_resources';
    let list=[];
    try{list=JSON.parse(localStorage.getItem(key)||'[]');}catch(e2){list=[];}
    if(on){ if(list.indexOf(r.slug)===-1) list.push(r.slug); }
    else { list=list.filter(x=>x!==r.slug); }
    localStorage.setItem(key, JSON.stringify(list));
    toast(on?'Ajouté à vos favoris':'Retiré de vos favoris');
  });
})();
