/* NkamVa — session live (formateur) : salle d'attente, live actif, modération chat/participants, questions du public */
(function(){
  var ICON = {
    exit:'<path d="M15 3h3.5A2.5 2.5 0 0 1 21 5.5v13a2.5 2.5 0 0 1-2.5 2.5H15"></path><path d="M10 16l5-4-5-4"></path><path d="M15 12H3"></path>',
    mic:'<path d="M12 2a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V5a3 3 0 0 1 3-3Z"></path><path d="M19 10v1a7 7 0 0 1-14 0v-1"></path><path d="M12 18v4"></path><path d="M8 22h8"></path>',
    micOff:'<path d="M12 2a3 3 0 0 1 3 3v6a3 3 0 0 1-.4 1.5"></path><path d="M9 9V5a3 3 0 0 1 5-2.2"></path><path d="M19 10v1a7 7 0 0 1-1 3.6"></path><path d="M5 10v1a7 7 0 0 0 11.7 5.1"></path><path d="M12 18v4"></path><path d="M8 22h8"></path><path d="M3 3l18 18"></path>',
    cam:'<rect x="3" y="6" width="12" height="12" rx="2.5"></rect><path d="m21 8-6 4 6 4V8Z"></path>',
    camOff:'<rect x="3" y="6" width="12" height="12" rx="2.5"></rect><path d="m21 8-6 4 6 4V8Z"></path><path d="M2 2l20 20"></path>',
    chat:'<path d="M21 11.5a8.38 8.38 0 0 1-9 8.4A8.5 8.5 0 1 1 20.9 9a8.4 8.4 0 0 1 .1 2.5Z"></path>',
    users:'<circle cx="9" cy="8" r="3.2"></circle><path d="M3.5 19c0-3 2.5-5 5.5-5s5.5 2 5.5 5"></path><path d="M15.5 5.5A3.2 3.2 0 0 1 17 11.6"></path><path d="M20.5 19c0-2.4-1.6-4.3-3.8-4.8"></path>',
    qa:'<circle cx="12" cy="12" r="9"></circle><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.9.5-1 1-1 2.2"></path><path d="M12 17.2v.1"></path>',
    close:'<path d="M6 6l12 12M18 6 6 18"></path>',
    send:'<path d="M22 2 11 13"></path><path d="M22 2 15 22l-4-9-9-4z"></path>',
    signal:'<rect x="3" y="12" width="3" height="7" fill="currentColor" stroke="none" rx="1"></rect><rect x="9" y="8" width="3" height="11" fill="currentColor" stroke="none" rx="1"></rect><rect x="15" y="4" width="3" height="15" fill="currentColor" stroke="none" rx="1"></rect>',
    share:'<rect x="2" y="4" width="20" height="14" rx="2"></rect><path d="M8 21h8M12 17v4"></path><path d="m9 10 3-3 3 3M12 7v6"></path>',
    trash:'<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"></path>',
    kick:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M18 8l4 4m0-4-4 4"></path>',
    up:'<path d="M12 19V5M5 12l7-7 7 7"></path>',
    link:'<path d="M10 13a5 5 0 0 0 7.5.5l2-2a5 5 0 0 0-7-7l-1 1"></path><path d="M14 11a5 5 0 0 0-7.5-.5l-2 2a5 5 0 0 0 7 7l1-1"></path>'
  };
  function svg(name,extra){ return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" '+(extra||'')+'>'+ICON[name]+'</svg>'; }

  var session = {
    title:'Live — revue de checklists QA',
    community:'QA & Tests logiciels',
    registered: 34,
    livesHref:'Lives Formateur.dc.html'
  };

  var shell = document.getElementById('live-host-shell');
  if(!shell) return;

  var state = 'pending'; // pending | live
  var micOn = true, camOn = true;
  var activePanel = 'chat';
  var viewers = 0, viewersTimer;
  var chatMsgs = [
    {who:'them', name:'Awa K.', text:'Bonsoir tout le monde 👋'},
    {who:'them', name:'Ibrahim S.', text:'Hâte de voir la partie sur les checklists de non-régression'}
  ];
  var questions = [
    {id:1, name:'Grace M.', text:'Comment priorisez-vous les cas de test quand le temps manque ?', votes:7, answered:false},
    {id:2, name:'Serge B.', text:'Avez-vous un gabarit pour les tests d\u2019API ?', votes:4, answered:false},
    {id:3, name:'Fadila T.', text:'Quelle différence entre checklist et plan de test ?', votes:2, answered:false}
  ];

  function renderPending(){
    shell.innerHTML =
      '<div class="replay-top">'+
        '<div class="rid"><img class="mki" src="assets/img/mark.svg" alt=""><div><div style="display:flex;align-items:center;gap:10px"><span class="replay-badge" style="background:var(--blue)">PLANIFIÉ</span><h1>'+session.title+'</h1></div><p class="replay-sub">'+session.community+' · '+session.registered+' inscrits</p></div></div>'+
        '<a class="replay-quit" href="'+session.livesHref+'">'+svg('exit')+'Quitter</a>'+
      '</div>'+
      '<div class="live-pending">'+
        '<div class="live-pending-ava">DT</div>'+
        '<h2>Prêt à démarrer ?</h2>'+
        '<p>'+session.registered+' apprenants sont inscrits et recevront une notification dès le lancement.</p>'+
        '<div class="live-pending-actions">'+
          '<button class="btn btn-p btn-lg" id="lc-start">Démarrer le live</button>'+
          '<button class="live-preview-link" id="lc-copylink">'+svg('link')+' Copier le lien d\u2019invitation</button>'+
        '</div>'+
      '</div>'+
      '<p class="live-chat-locked">Le chat et les questions du public s\u2019ouvriront au démarrage.</p>';

    document.getElementById('lc-start').addEventListener('click', function(){ state='live'; renderLive(); });
    document.getElementById('lc-copylink').addEventListener('click', function(){ window.toast && window.toast('Lien d\u2019invitation copié'); });
  }

  function renderLive(){
    shell.innerHTML =
      '<div class="replay-top">'+
        '<div class="rid"><img class="mki" src="assets/img/mark.svg" alt=""><div><div style="display:flex;align-items:center;gap:10px"><span class="replay-badge live">EN DIRECT</span><h1>'+session.title+'</h1><span class="replay-sub" id="lc-elapsed" style="margin:0">00:00</span></div><p class="replay-sub" id="lc-viewers">'+session.community+' · 0 spectateur</p></div></div>'+
        '<button class="live-end-btn" id="ctl-end">'+svg('exit')+'Terminer le live</button>'+
      '</div>'+
      '<div class="live-body">'+
        '<div class="live-stage">'+
          '<div class="live-grid" style="grid-template-columns:1fr">'+
            '<div class="live-tile speaking"><span class="lt-tag" id="you-tag">'+svg('mic')+'Daniel Tongo (vous) · Formateur</span><span class="lt-signal">'+svg('signal')+'</span></div>'+
          '</div>'+
          '<div class="live-controls-bar">'+
            '<button id="ctl-mic" title="Micro">'+svg('mic')+'</button>'+
            '<button id="ctl-cam" title="Caméra">'+svg('cam')+'</button>'+
            '<button id="ctl-share" title="Partager l\u2019écran">'+svg('share')+'</button>'+
            '<button id="ctl-chat" title="Chat">'+svg('chat')+'</button>'+
            '<button id="ctl-part" title="Participants">'+svg('users')+'</button>'+
            '<button id="ctl-qa" title="Questions">'+svg('qa')+'<span class="bdg" id="qa-bdg">'+questions.filter(function(q){return !q.answered;}).length+'</span></button>'+
          '</div>'+
        '</div>'+
        '<div class="live-side" id="live-side"></div>'+
      '</div>';

    document.getElementById('ctl-end').addEventListener('click', function(){
      if(!confirm('Terminer le live ? Les apprenants seront déconnectés.')) return;
      window.toast && window.toast('Live terminé — pensez à publier le replay');
      location.href = session.livesHref;
    });
    document.getElementById('ctl-mic').addEventListener('click', function(){
      micOn = !micOn; this.classList.toggle('off', !micOn); this.innerHTML = svg(micOn?'mic':'micOff');
      var tag = document.getElementById('you-tag'); tag.classList.toggle('muted', !micOn); tag.innerHTML = svg(micOn?'mic':'micOff')+'Daniel Tongo (vous) · Formateur';
    });
    document.getElementById('ctl-cam').addEventListener('click', function(){
      camOn = !camOn; this.classList.toggle('off', !camOn); this.innerHTML = svg(camOn?'cam':'camOff');
      toast(camOn?'Caméra activée':'Caméra désactivée');
    });
    var sharing = false;
    document.getElementById('ctl-share').addEventListener('click', function(){
      sharing = !sharing; this.classList.toggle('on-panel', sharing);
      window.toast && window.toast(sharing ? 'Partage d\u2019écran démarré' : 'Partage d\u2019écran arrêté');
    });
    document.getElementById('ctl-chat').addEventListener('click', function(){ togglePanel('chat'); });
    document.getElementById('ctl-part').addEventListener('click', function(){ togglePanel('participants'); });
    document.getElementById('ctl-qa').addEventListener('click', function(){ togglePanel('qa'); });

    var elapsed = 0;
    setInterval(function(){
      elapsed++;
      var m = Math.floor(elapsed/60), s = elapsed%60;
      var el = document.getElementById('lc-elapsed'); if(el) el.textContent = (m<10?'0':'')+m+':'+(s<10?'0':'')+s;
    }, 1000);

    viewers = 18;
    clearInterval(viewersTimer);
    viewersTimer = setInterval(function(){
      viewers = Math.max(12, viewers + Math.round((Math.random()-0.3)*3));
      var el = document.getElementById('lc-viewers'); if(el) el.textContent = session.community+' · '+viewers+' spectateurs';
    }, 4000);

    togglePanel('chat');
  }

  function panelHead(title){
    return '<div class="live-side-head"><span>'+title+'</span><button id="panel-close">'+svg('close')+'</button></div>';
  }

  function renderChatPanel(){
    var side = document.getElementById('live-side');
    side.innerHTML = panelHead('CHAT') + '<div class="live-chat-thread" id="lc-thread"></div>'
      + '<div class="live-chat-compose"><input id="lc-input" type="text" placeholder="Écrire un message…"><button id="lc-send">'+svg('send')+'</button></div>';
    paintThread();
    document.getElementById('lc-send').addEventListener('click', sendMsg);
    document.getElementById('lc-input').addEventListener('keydown', function(e){ if(e.key==='Enter') sendMsg(); });
  }
  function paintThread(){
    var t = document.getElementById('lc-thread'); if(!t) return;
    t.innerHTML = chatMsgs.length ? chatMsgs.map(function(m,i){
      return '<div class="lbubble '+(m.who==='me'?'me':'them')+'" data-i="'+i+'">'+(m.who==='me'?'':'<b>'+m.name+'</b>')+m.text
        + (m.who!=='me' ? '<button class="chat-mod" data-del="'+i+'" title="Masquer">'+svg('trash')+'</button>' : '')
        +'</div>';
    }).join('') : '<div class="live-chat-empty">Aucun message pour l\u2019instant.</div>';
    t.scrollTop = t.scrollHeight;
    t.querySelectorAll('[data-del]').forEach(function(btn){
      btn.addEventListener('click', function(){ chatMsgs.splice(parseInt(btn.getAttribute('data-del'),10),1); paintThread(); window.toast && window.toast('Message masqué'); });
    });
  }
  function sendMsg(){
    var input = document.getElementById('lc-input'); var text = input.value.trim(); if(!text) return;
    chatMsgs.push({who:'me', text:text}); input.value=''; paintThread();
  }

  function renderParticipantsPanel(){
    var side = document.getElementById('live-side');
    var people = [
      {i:'AK', n:'Awa K.'}, {i:'IS', n:'Ibrahim S.'}, {i:'GM', n:'Grace M.'}, {i:'SB', n:'Serge B.'}
    ];
    side.innerHTML = panelHead('PARTICIPANTS ('+people.length+')') + '<div class="live-plist">'
      + people.map(function(p){
        return '<div class="live-p"><span class="ava sm">'+p.i+'</span><b>'+p.n+'</b><span class="icons"><button class="chat-mod" data-kick="'+p.n+'" title="Retirer">'+svg('kick')+'</button></span></div>';
      }).join('') + '</div>';
    side.querySelectorAll('[data-kick]').forEach(function(btn){
      btn.addEventListener('click', function(){
        btn.closest('.live-p').remove();
        window.toast && window.toast(btn.getAttribute('data-kick')+' a été retiré du live');
      });
    });
  }

  function renderQaPanel(){
    var side = document.getElementById('live-side');
    var sorted = questions.slice().sort(function(a,b){ return b.votes-a.votes; });
    side.innerHTML = panelHead('QUESTIONS DU PUBLIC') + '<div class="live-qa">'
      + (sorted.length ? sorted.map(function(q){
          return '<div class="qa-item'+(q.answered?' done':'')+'" data-id="'+q.id+'">'
            + '<span class="qa-votes">'+svg('up')+q.votes+'</span>'
            + '<div class="qa-tx"><b>'+q.name+'</b><p>'+q.text+'</p></div>'
            + (q.answered ? '<span class="qa-done-tag">Répondu</span>' : '<button class="btn btn-o btn-sm" data-answer="'+q.id+'">Marquer répondu</button>')
            + '</div>';
        }).join('') : '<div class="live-chat-empty">Aucune question pour l\u2019instant.</div>')
      + '</div>';
    side.querySelectorAll('[data-answer]').forEach(function(btn){
      btn.addEventListener('click', function(){
        var id = parseInt(btn.getAttribute('data-answer'),10);
        questions.forEach(function(q){ if(q.id===id) q.answered = true; });
        renderQaPanel();
        var bdg = document.getElementById('qa-bdg'); if(bdg) bdg.textContent = questions.filter(function(q){return !q.answered;}).length;
      });
    });
  }

  function togglePanel(name){
    var side = document.getElementById('live-side');
    ['ctl-chat','ctl-part','ctl-qa'].forEach(function(id){ var b=document.getElementById(id); if(b) b.classList.remove('on-panel'); });
    activePanel = name; side.style.display='flex';
    var btnId = name==='chat'?'ctl-chat':name==='participants'?'ctl-part':'ctl-qa';
    var btn = document.getElementById(btnId); if(btn) btn.classList.add('on-panel');
    if(name==='chat') renderChatPanel();
    else if(name==='participants') renderParticipantsPanel();
    else renderQaPanel();
  }

  renderPending();
})();
