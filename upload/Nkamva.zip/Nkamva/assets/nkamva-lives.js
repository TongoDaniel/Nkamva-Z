/* NkamVa — Mes lives & agenda : sessions à venir / replays des communautés rejointes */
(function(){
  var upcoming = [
    {day:'23',dow:'Jeu',title:'Live — revue de checklists QA',comm:'QA & Tests logiciels',meta:'18h00 UTC',cta:'Voir',soon:false,href:'Live.dc.html'}
  ];
  var replays = [
    {day:'16',mon:'Juil',title:'Concevoir un plan de test solide',comm:'QA & Tests logiciels',formateur:'Daniel Tongo',dur:'42:10',href:'Replay.dc.html'},
    {day:'9',mon:'Juil',title:'Revue de code en direct : gestion des erreurs',comm:'Ingénierie logicielle Afrique',formateur:'Aminata Sow',dur:'51:30',href:'Replay.dc.html'},
    {day:'25',mon:'Juin',title:"Architecture d'un système de paiement résilient",comm:'Ingénierie logicielle Afrique',formateur:'Aminata Sow',dur:'38:05',href:'Replay.dc.html'}
  ];

  document.getElementById('lv-n-upcoming').textContent = upcoming.length;
  document.getElementById('lv-n-replays').textContent = replays.length;

  var list = document.getElementById('live-list');
  var tabs = document.querySelectorAll('#live-tabs button');

  function empty(msg){ return '<p class="live-empty">'+msg+'</p>'; }

  function upcomingCard(u){
    return '<div class="live-item" data-title="'+u.title+'"><div class="live-date"><b>'+u.day+'</b><span>'+u.dow+'</span></div>'
      +'<div class="res-tx"><h3>'+u.title+'</h3><p>'+u.comm+' · '+u.meta+'</p></div>'
      +'<a class="btn btn-o btn-sm'+(u.soon?' soon':'')+'" href="'+u.href+'">'+u.cta+'</a></div>';
  }
  function replayCard(r){
    return '<div class="live-item replay" data-title="'+r.title+'"><div class="live-date"><b>'+r.day+'</b><span>'+r.mon+'</span></div>'
      +'<div class="res-tx"><h3>'+r.title+'</h3><p>'+r.comm+' · '+r.formateur+' · '+r.dur+'</p></div>'
      +'<a class="btn btn-p btn-sm" href="'+r.href+'">Regarder</a></div>';
  }

  function render(tab){
    if(tab==='replays'){
      list.innerHTML = replays.length ? replays.map(replayCard).join('') : empty('Aucun replay disponible.');
    } else {
      list.innerHTML = upcoming.length ? upcoming.map(upcomingCard).join('') : empty('Aucun live planifié dans vos communautés.');
    }
  }

  function goToEvent(tab,title){
    tabs.forEach(function(b){ b.classList.toggle('on', b.dataset.tab===tab); });
    render(tab);
    var row = list.querySelector('[data-title="'+title.replace(/"/g,'')+'"]');
    if(row){ row.classList.add('flash'); setTimeout(function(){ row.classList.remove('flash'); }, 1200); }
  }

  tabs.forEach(function(btn){
    btn.addEventListener('click', function(){
      tabs.forEach(function(b){ b.classList.remove('on'); });
      btn.classList.add('on');
      render(btn.dataset.tab);
    });
  });

  var agenda = document.getElementById('lv-agenda');
  if(agenda){
    agenda.innerHTML = upcoming.length ? upcoming.map(function(u){
      return '<div class="lv-agenda-item"><div class="live-date"><b>'+u.day+'</b><span>'+u.dow+'</span></div>'
        +'<div><h5>'+u.title+'</h5><p>'+u.comm+' · '+u.meta+'</p></div></div>';
    }).join('') : 'Aucun rendez-vous.';
  }

  // ---- calendrier juillet 2026 : jours à live/replay cliquables ----
  var events = {};
  upcoming.forEach(function(u){ (events[+u.day] = events[+u.day]||[]).push({tab:'upcoming',title:u.title}); });
  replays.forEach(function(r){ if(r.mon==='Juil') (events[+r.day] = events[+r.day]||[]).push({tab:'replays',title:r.title}); });
  var today = 21, leading = 2, total = 31;
  var grid = document.getElementById('livecal-grid');
  if(grid){
    var html = ['L','M','M','J','V','S','D'].map(function(d){ return '<span>'+d+'</span>'; }).join('');
    for(var i=0;i<leading;i++) html += '<b class="mut"></b>';
    for(var d=1; d<=total; d++){
      var ev = events[d];
      var cls = [];
      if(d===today) cls.push('today');
      if(ev) cls.push('has');
      html += '<b class="'+cls.join(' ')+'"'+(ev?' data-day="'+d+'" title="'+ev.map(function(e){return e.title;}).join(', ')+'"':'')+'>'+d+'</b>';
    }
    var trailing = (leading+total)%7; if(trailing) for(var t=trailing;t<7;t++) html += '<b class="mut"></b>';
    grid.innerHTML = html;
    grid.addEventListener('click', function(e){
      var b = e.target.closest('b.has'); if(!b) return;
      var ev = events[+b.dataset.day][0];
      goToEvent(ev.tab, ev.title);
    });
  }

  render('upcoming');
})();
