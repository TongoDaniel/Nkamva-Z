/* NkamVa Landing — carousels, FAQ, reveals, images */
(function(){
/* reveal au scroll */
var srs=[].slice.call(document.querySelectorAll('[data-sr]'));
if('IntersectionObserver'in window){
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('vis');io.unobserve(e.target);}});},{rootMargin:'0px 0px -8% 0px',threshold:.08});
  srs.forEach(function(el){io.observe(el);});
}else srs.forEach(function(el){el.classList.add('vis');});

/* images produit : skeleton -> fade in */
[].slice.call(document.querySelectorAll('.ph img')).forEach(function(img){
  function ok(){img.closest('.ph').classList.add('ld');}
  if(img.complete&&img.naturalWidth)ok();else img.addEventListener('load',ok);
});

/* hero A : mini-carousel de cartes */
var hc=document.getElementById('hcar');
if(hc){
  var trk=hc.querySelector('.trk'),slides=trk.children.length,i=0,tm,
  dots=hc.querySelector('.dots'),prev=hc.querySelector('[data-prev]'),next=hc.querySelector('[data-next]');
  for(var d=0;d<slides;d++){var b=document.createElement('button');b.setAttribute('aria-label','Carte '+(d+1));if(!d)b.className='on';dots.appendChild(b);}
  function go(n,user){
    i=(n+slides)%slides;
    trk.style.transform='translateX(calc('+(-i*100)+'% - '+(i*16)+'px))';
    [].forEach.call(dots.children,function(b,k){b.classList.toggle('on',k===i);});
    if(user)restart();
  }
  dots.addEventListener('click',function(e){var b=e.target.closest('button');if(b)go([].indexOf.call(dots.children,b),true);});
  if(prev)prev.addEventListener('click',function(){go(i-1,true);});
  if(next)next.addEventListener('click',function(){go(i+1,true);});
  var reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  function tick(){tm=setInterval(function(){go(i+1);},4600);}
  function restart(){clearInterval(tm);if(!reduced)tick();}
  if(!reduced)tick();
  hc.addEventListener('mouseenter',function(){clearInterval(tm);});
  hc.addEventListener('mouseleave',function(){restart();});
  hc.addEventListener('focusin',function(){clearInterval(tm);});
  document.addEventListener('visibilitychange',function(){document.hidden?clearInterval(tm):restart();});
  /* swipe */
  var x0=null;
  hc.addEventListener('touchstart',function(e){x0=e.touches[0].clientX;},{passive:true});
  hc.addEventListener('touchend',function(e){if(x0==null)return;var dx=e.changedTouches[0].clientX-x0;if(Math.abs(dx)>42)go(i+(dx<0?1:-1),true);x0=null;},{passive:true});
}

/* carousel ressources populaires — défilement infini */
var rw=document.getElementById('rcar');
if(rw){
  var rt=rw.querySelector('.rtrack'),rp=rw.querySelector('[data-prev]'),rn=rw.querySelector('[data-next]');
  var orig=[].slice.call(rt.querySelectorAll('.rc'));
  orig.forEach(function(c){var k=c.cloneNode(true);k.setAttribute('aria-hidden','true');k.querySelectorAll('a,button').forEach(function(el){el.setAttribute('tabindex','-1');});rt.appendChild(k);});
  var half=0;
  function measure(){half=0;orig.forEach(function(c){half+=c.getBoundingClientRect().width+18;});}
  measure();window.addEventListener('resize',measure);
  function wrap(){
    if(pos>=half)pos-=half;
    else if(pos<=0)pos+=half;
    rt.scrollLeft=pos;
  }
  var reduced=matchMedia('(prefers-reduced-motion: reduce)').matches,paused=false,resume,pos=1;
  function hold(ms){paused=true;clearTimeout(resume);if(ms)resume=setTimeout(function(){paused=false;},ms);}
  if(!reduced){
    rt.scrollLeft=pos;
    var last=null;
    requestAnimationFrame(function loop(t){
      if(last!=null&&!paused&&!document.hidden){pos+=Math.min(t-last,50)*.028;wrap();}
      last=t;requestAnimationFrame(loop);
    });
    rt.addEventListener('scroll',function(){if(paused)pos=rt.scrollLeft;},{passive:true});
    rw.addEventListener('mouseenter',function(){hold();});
    rw.addEventListener('mouseleave',function(){clearTimeout(resume);paused=false;});
    rt.addEventListener('touchstart',function(){hold(3200);},{passive:true});
    rw.addEventListener('focusin',function(){hold();});
    rw.addEventListener('focusout',function(){clearTimeout(resume);paused=false;});
  }else rt.addEventListener('scroll',function(){pos=rt.scrollLeft;wrap();},{passive:true});
  function step(){var c=rt.querySelector('.rc');return c?c.getBoundingClientRect().width+18:314;}
  if(rp)rp.addEventListener('click',function(){hold(2600);rt.scrollBy({left:-step()*2,behavior:'smooth'});});
  if(rn)rn.addEventListener('click',function(){hold(2600);rt.scrollBy({left:step()*2,behavior:'smooth'});});
}

/* menu mobile */
var mb=document.querySelector('.mnav-btn'),mn=document.querySelector('.mnav');
if(mb&&mn){
  mb.addEventListener('click',function(){
    var open=mn.classList.toggle('open');
    mb.setAttribute('aria-expanded',open);
  });
  mn.addEventListener('click',function(e){if(e.target.closest('a')){mn.classList.remove('open');mb.setAttribute('aria-expanded','false');}});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&mn.classList.contains('open')){mn.classList.remove('open');mb.setAttribute('aria-expanded','false');mb.focus();}});
}

/* FAQ accordéon */
[].slice.call(document.querySelectorAll('.qa')).forEach(function(qa){
  var q=qa.querySelector('.q'),a=qa.querySelector('.a');
  q.setAttribute('aria-expanded','false');
  q.addEventListener('click',function(){
    var open=qa.classList.toggle('open');
    q.setAttribute('aria-expanded',open);
    a.style.maxHeight=open?a.scrollHeight+'px':'0px';
    if(open)document.querySelectorAll('.qa.open').forEach(function(o){
      if(o!==qa){o.classList.remove('open');o.querySelector('.a').style.maxHeight='0px';o.querySelector('.q').setAttribute('aria-expanded','false');}
    });
  });
});
})();
