/* NkamVa — Notifications (apprenant) : liste complète, marquage lu/non lu persistant */
(function(){
  var MSG='<path d="M21 11.5a8.38 8.38 0 0 1-9 8.4A8.5 8.5 0 1 1 20.9 9a8.4 8.4 0 0 1 .1 2.5Z"></path>';
  var CLOCK='<circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3.5 2"></path>';
  var DOC='<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"></path>';
  var RECEIPT='<path d="M4 3h16v18l-2-1.4-2 1.4-2-1.4-2 1.4-2-1.4-2 1.4-2-1.4-2 1.4V3Z"></path><path d="M8 8h8M8 12h8M8 16h5"></path>';
  var PLAY='<circle cx="12" cy="12" r="9"></circle><path d="M10 8.5l5 3.5-5 3.5z" fill="currentColor" stroke="none"></path>';
  var HEART='<path d="M12 21s-7.5-4.6-9.8-9A5.6 5.6 0 0 1 12 6.3 5.6 5.6 0 0 1 21.8 12c-2.3 4.4-9.8 9-9.8 9z"></path>';

  var notifs = [
    {id:'n1', icon:MSG, title:"Nouveau message dans QA & Tests logiciels", when:'il y a 2 h', href:'Communaute apprenant.dc.html?c=qa-tests-logiciels'},
    {id:'n2', icon:CLOCK, title:'Rappel : live jeudi à 18h00', when:'il y a 1 j', href:'Mes lives.dc.html'},
    {id:'n3', icon:DOC, title:"Nouvelle ressource d'Aminata Sow ajoutée au catalogue", when:'il y a 3 j', href:'Catalogue apprenant.dc.html'},
    {id:'n4', icon:MSG, title:"Réponse d'Aminata Sow à votre question dans le forum", when:'il y a 4 j', href:'Communaute apprenant.dc.html?c=ingenierie-logicielle-afrique'},
    {id:'n5', icon:PLAY, title:'Le replay « Concevoir un plan de test solide » est disponible', when:'il y a 5 j', href:'Replay.dc.html'},
    {id:'n6', icon:RECEIPT, title:'Paiement confirmé — abonnement QA & Tests logiciels', when:'il y a 6 j', href:'Mes achats.dc.html'},
    {id:'n7', icon:MSG, title:'Nouveau message dans Ingénierie logicielle Afrique', when:'il y a 1 sem.', href:'Communaute apprenant.dc.html?c=ingenierie-logicielle-afrique'},
    {id:'n8', icon:CLOCK, title:'Live terminé : revue de code avec Aminata Sow', when:'il y a 1 sem.', href:'Mes lives.dc.html'},
    {id:'n9', icon:HEART, title:'Bienvenue sur NkamVa ! Complétez votre profil pour mieux profiter des communautés', when:'il y a 2 sem.', href:'Profil et parametres.dc.html'}
  ];
  var READ_KEY = 'nk_notifs_read';
  var defaultUnread = ['n1','n2','n3'];
  function loadRead(){
    try{ var r = JSON.parse(localStorage.getItem(READ_KEY)); if(Array.isArray(r)) return r; }catch(e){}
    return notifs.map(function(n){return n.id;}).filter(function(id){return defaultUnread.indexOf(id)===-1;});
  }
  var read = loadRead();
  function isRead(id){ return read.indexOf(id)!==-1; }
  function saveRead(){ localStorage.setItem(READ_KEY, JSON.stringify(read)); }

  var list = document.getElementById('notif-list');
  function row(n){
    return '<a class="nt nt-page'+(isRead(n.id)?'':' unread')+'" href="'+n.href+'" data-id="'+n.id+'"><span class="nt-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+n.icon+'</svg></span><span class="nt-tx"><b>'+n.title+'</b><small>'+n.when+'</small></span></a>';
  }
  function render(){
    list.innerHTML = notifs.map(row).join('');
    var unreadCount = notifs.filter(function(n){return !isRead(n.id);}).length;
    document.getElementById('notif-count').textContent = unreadCount ? unreadCount+' non lue'+(unreadCount>1?'s':'') : 'Tout est lu';
  }
  render();

  list.addEventListener('click', function(e){
    var row = e.target.closest('.nt'); if(!row) return;
    var id = row.dataset.id;
    if(read.indexOf(id)===-1){ read.push(id); saveRead(); }
  });

  document.getElementById('notif-readall').addEventListener('click', function(){
    read = notifs.map(function(n){return n.id;});
    saveRead(); render();
    toast('Toutes les notifications sont marquées comme lues');
  });
})();
