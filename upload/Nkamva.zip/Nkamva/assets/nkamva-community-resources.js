/* NkamVa — ressources incluses avec l'abonnement de chaque communauté (pas de vente à l'unité) */
window.NK_COMM_RES = {
  'qa-tests-logiciels':[
    {title:'Checklist de non-régression v3',type:'PDF',desc:'La checklist utilisée en interne avant chaque mise en production.'},
    {title:'Grille d\u2019entretien QA',type:'Modèle',desc:'Un modèle de grille pour structurer vos entretiens de recrutement QA.'}
  ],
  'ingenierie-logicielle-afrique':[
    {title:'Modèle de revue de code',type:'Modèle',desc:'La grille utilisée pour les revues de code entre pairs de la communauté.'},
    {title:'Guide d\u2019architecture microservices',type:'PDF',desc:'Un guide condensé des patterns abordés lors des sessions live.'}
  ]
};
