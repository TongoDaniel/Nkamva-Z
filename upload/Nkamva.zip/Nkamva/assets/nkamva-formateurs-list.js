/* NkamVa — logique listing Formateurs : onglets catégorie, recherche */
(function(){
  const F = NKTRAIN.list;
  const grid = document.getElementById('tgrid');
  const search = document.getElementById('tq');
  const resN = document.getElementById('tresn');
  const tabsWrap = document.getElementById('ttabs');
  const state = {cat:'all', q:''};

  const tabs = [{id:'all',label:'Tous'}].concat(NKAMVA.categories.map(c=>({id:c.id,label:c.label})));
  tabsWrap.innerHTML = tabs.map(t=>'<button data-cat="'+t.id+'" class="'+(t.id==='all'?'on':'')+'">'+t.label+'</button>').join('');

  function apply(){
    let list = F.filter(f=>{
      if(state.cat!=='all' && f.category.id!==state.cat) return false;
      if(state.q){const q=state.q.toLowerCase(); if(!(f.name.toLowerCase().includes(q)||f.role.toLowerCase().includes(q))) return false;}
      return true;
    });
    list.sort((a,b)=>b.students-a.students);
    render(list);
  }
  function render(list){
    resN.innerHTML = '<b>'+list.length+'</b> formateur'+(list.length>1?'s':'');
    if(!list.length){
      grid.className='';
      grid.innerHTML='<div class="empty" style="grid-column:1/-1"><div class="eic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg></div><h3>Aucun formateur trouvé</h3><p>Essayez une autre catégorie ou un autre terme de recherche.</p></div>';
      return;
    }
    grid.className='tgrid';
    grid.innerHTML = list.map((f,i)=>trainerCard(f,i)).join('');
  }
  tabsWrap.addEventListener('click',e=>{
    const b=e.target.closest('button[data-cat]'); if(!b) return;
    state.cat=b.dataset.cat;
    [...tabsWrap.children].forEach(x=>x.classList.toggle('on',x===b));
    apply();
  });
  let t; search.addEventListener('input',()=>{clearTimeout(t); t=setTimeout(()=>{state.q=search.value.trim(); apply();},220);});
  apply();
})();
