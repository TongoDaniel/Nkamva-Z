/* NkamVa — Aide & FAQ : recherche + accordéon */
(function(){
  const search = document.getElementById('afsearch');
  const groups = document.querySelectorAll('.afgrp-wrap');
  document.querySelectorAll('.atags button').forEach(b=>b.addEventListener('click',()=>{
    search.value = b.textContent;
    filter();
  }));
  document.querySelectorAll('.atopic').forEach(t=>t.addEventListener('click',()=>{
    const target = document.getElementById(t.dataset.target);
    if(target) target.scrollIntoView({behavior:'smooth', block:'start'});
  }));
  function filter(){
    const q = search.value.trim().toLowerCase();
    groups.forEach(g=>{
      let any=false;
      g.querySelectorAll('.qa').forEach(qa=>{
        const match = !q || qa.textContent.toLowerCase().includes(q);
        qa.style.display = match ? '' : 'none';
        if(match) any=true;
      });
      g.style.display = any ? '' : 'none';
    });
  }
  let t; search.addEventListener('input',()=>{clearTimeout(t); t=setTimeout(filter,150);});

  document.querySelectorAll('.afaq .qa').forEach(qa=>{
    const q=qa.querySelector('.q'), a=qa.querySelector('.a');
    q.setAttribute('aria-expanded','false');
    q.addEventListener('click',()=>{
      const open=qa.classList.toggle('open');
      q.setAttribute('aria-expanded',open);
      a.style.maxHeight = open ? a.scrollHeight+'px' : '0px';
    });
  });
})();
