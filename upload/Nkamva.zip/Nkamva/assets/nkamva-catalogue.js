/* NkamVa — logique catalogue : recherche, filtres, tri, pagination, état URL */
(function(){
  const R = NKAMVA.resources;
  const grid = document.getElementById('grid');
  const search = document.getElementById('q');
  const sortSel = document.getElementById('sort');
  const resN = document.getElementById('resn');
  const active = document.getElementById('activef');
  const loadWrap = document.getElementById('loadmore');
  const PAGE = 9;
  const state = {q:'',cats:new Set(),fmts:new Set(),sort:'pop',shown:PAGE};

  // compteurs par catégorie / format / niveau
  function counts(key,val){return R.filter(r=>r[key]===val||(r[key]&&r[key].id===val)).length;}

  // rendu des filtres
  function opt(group,val,label,n,radioLook){
    return '<label class="fopt"><input type="checkbox" data-g="'+group+'" value="'+val+'"><span class="bx'+(radioLook?' rd':'')+'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span>'+label+'<span class="cnt">'+n+'</span></label>';
  }
  document.getElementById('f-cats').innerHTML = NKAMVA.categories.map(c=>opt('cats',c.id,c.label,R.filter(r=>r.cat===c.id).length)).join('');
  document.getElementById('f-fmts').innerHTML = Object.keys(NKAMVA.formats).map(k=>opt('fmts',k,NKAMVA.formats[k].label,R.filter(r=>r.fmt===k).length)).join('');

  function apply(){
    let list = R.filter(r=>{
      if(state.q){const q=state.q.toLowerCase();if(!(r.title.toLowerCase().includes(q)||r.author.name.toLowerCase().includes(q)||r.category.label.toLowerCase().includes(q)))return false;}
      if(state.cats.size&&!state.cats.has(r.cat))return false;
      if(state.fmts.size&&!state.fmts.has(r.fmt))return false;
      return true;
    });
    const s=state.sort;
    list.sort((a,b)=> s==='price-a'?a.price-b.price : s==='price-d'?b.price-a.price : s==='new'? (b.updated>a.updated?1:-1) : b.students-a.students);
    render(list);
    syncUrl();
  }

  function render(list){
    resN.innerHTML = '<b>'+list.length+'</b> ressource'+(list.length>1?'s':'');
    // pastilles actives
    const pills=[];
    state.cats.forEach(c=>pills.push(pill('cats',c,NKAMVA.categories.find(x=>x.id===c).label)));
    state.fmts.forEach(f=>pills.push(pill('fmts',f,NKAMVA.formats[f].label)));
    if(state.q)pills.push(pill('q',state.q,'« '+state.q+' »'));
    active.innerHTML = pills.length?pills.join('')+'<button class="fclear" id="clearall">Tout effacer</button>':'';
    active.style.display = pills.length?'flex':'none';

    if(!list.length){
      grid.className='';
      grid.innerHTML='<div class="empty" style="grid-column:1/-1"><div class="eic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg></div><h3>Aucune ressource trouvée</h3><p>Essayez d\u2019élargir votre recherche ou de retirer un filtre.</p><button class="btn btn-o" id="reset2">Réinitialiser les filtres</button></div>';
      loadWrap.innerHTML=''; return;
    }
    grid.className='rgrid';
    const slice=list.slice(0,state.shown);
    grid.innerHTML = slice.map((r,i)=>rcCard(r,i)).join('');
    loadWrap.innerHTML = list.length>state.shown ? '<button class="btn btn-o btn-lg" id="more">Afficher plus ('+(list.length-state.shown)+')</button>' : '';
    if(document.body.classList.contains('is-ready')){/* already revealed */}
  }
  function pill(g,v,label){return '<span class="pill">'+label+'<button data-rm data-g="'+g+'" data-v="'+v+'" aria-label="Retirer"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button></span>';}

  // événements
  document.querySelector('.filters').addEventListener('change',e=>{
    const i=e.target.closest('input[data-g]');if(!i)return;
    const set=state[i.dataset.g];i.checked?set.add(i.value):set.delete(i.value);
    state.shown=PAGE;apply();
  });
  active.addEventListener('click',e=>{
    const rm=e.target.closest('[data-rm]');
    if(rm){const g=rm.dataset.g;if(g==='q'){state.q='';search.value='';}else state[g].delete(rm.dataset.v);state.shown=PAGE;syncChecks();apply();}
    if(e.target.id==='clearall')clearAll();
  });
  loadWrap.addEventListener('click',e=>{if(e.target.id==='more'){state.shown+=PAGE;apply();}});
  grid.addEventListener('click',e=>{if(e.target.id==='reset2')clearAll();});
  let t;search.addEventListener('input',()=>{clearTimeout(t);t=setTimeout(()=>{state.q=search.value.trim();state.shown=PAGE;apply();},220);});
  sortSel.addEventListener('change',()=>{state.sort=sortSel.value;apply();});
  document.getElementById('fbtn').addEventListener('click',()=>toggleDrawer(true));
  document.getElementById('fbg').addEventListener('click',()=>toggleDrawer(false));
  document.getElementById('fdone').addEventListener('click',()=>toggleDrawer(false));

  function toggleDrawer(on){document.querySelector('.filters').classList.toggle('open',on);document.getElementById('fbg').classList.toggle('on',on);}
  function clearAll(){state.cats.clear();state.fmts.clear();state.q='';search.value='';state.shown=PAGE;syncChecks();apply();}
  window.NK_clearAll=clearAll;
  function syncChecks(){document.querySelectorAll('input[data-g]').forEach(i=>{i.checked=state[i.dataset.g]&&state[i.dataset.g].has&&state[i.dataset.g].has(i.value);});}

  function syncUrl(){
    const p=new URLSearchParams();
    if(state.q)p.set('q',state.q);
    if(state.cats.size)p.set('cat',[...state.cats].join(','));
    if(state.fmts.size)p.set('fmt',[...state.fmts].join(','));
    if(state.sort!=='pop')p.set('tri',state.sort);
    history.replaceState(null,'','?'+p.toString());
  }
  // état initial depuis l'URL
  (function initFromUrl(){
    const p=new URLSearchParams(location.search);
    if(p.get('q')){state.q=p.get('q');search.value=state.q;}
    if(p.get('cat'))p.get('cat').split(',').forEach(v=>state.cats.add(v));
    if(p.get('fmt'))p.get('fmt').split(',').forEach(v=>state.fmts.add(v));
    if(p.get('tri')){state.sort=p.get('tri');sortSel.value=state.sort;}
    syncChecks();
  })();

  apply();
})();
