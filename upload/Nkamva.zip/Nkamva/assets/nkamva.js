/* NkamVa — comportements partagés : skeleton → reveal, toasts, favoris */
(function(){
document.body.classList.add('is-loading');
window.addEventListener('DOMContentLoaded',function(){
  var d=Math.min(1100,600+Math.random()*400);
  setTimeout(function(){
    document.body.classList.remove('is-loading');
    document.body.classList.add('is-ready');
  },d);
});
var box;
window.toast=function(msg,opts){
  opts=opts||{};
  if(!box){box=document.createElement('div');box.id='toasts';document.body.appendChild(box);}
  var t=document.createElement('div');t.className='toast';
  t.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"></path></svg><span></span>';
  t.querySelector('span').textContent=msg;
  if(opts.action){var b=document.createElement('button');b.textContent=opts.action;b.onclick=function(){opts.onAction&&opts.onAction();kill();};t.appendChild(b);}
  box.appendChild(t);
  var tm=setTimeout(kill,opts.duration||3200);
  function kill(){clearTimeout(tm);t.classList.add('out');setTimeout(function(){t.remove();},300);}
  return kill;
};
document.addEventListener('click',function(e){
  var s=e.target.closest('.soon');
  if(s){e.preventDefault();toast('Écran hors du périmètre de cette refonte');return;}
  var f=e.target.closest('.fav');if(!f)return;
  e.preventDefault();e.stopPropagation();
  var on=f.classList.toggle('on');
  f.setAttribute('aria-pressed',on);
  f.setAttribute('aria-label',on?'Retirer des favoris':'Ajouter aux favoris');
  var slug=f.dataset.slug, kind=f.dataset.kind;
  if(slug&&kind){
    var key='nk_fav_'+kind+'s';
    var list=[];
    try{list=JSON.parse(localStorage.getItem(key)||'[]');}catch(e2){list=[];}
    if(on){ if(list.indexOf(slug)===-1) list.push(slug); }
    else { list=list.filter(function(x){return x!==slug;}); }
    localStorage.setItem(key, JSON.stringify(list));
  }
  if(f.dataset.silent!=null)return;
  toast(on?'Ajouté à vos favoris':'Retiré de vos favoris');
});
})();
