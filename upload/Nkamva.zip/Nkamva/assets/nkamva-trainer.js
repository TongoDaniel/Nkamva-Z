/* NkamVa — espace formateur : popovers, kebabs, modales, onglets génériques */
window.NK_SPACE = 'trainer';
(function(){
  function wire(btnId,wrapId){
    var btn=document.getElementById(btnId), wrap=document.getElementById(wrapId);
    if(!btn||!wrap)return;
    btn.addEventListener('click',function(e){
      e.stopPropagation();
      var willOpen=!wrap.classList.contains('open');
      document.querySelectorAll('.hpop.open').forEach(function(w){w.classList.remove('open');var b=w.querySelector('[aria-expanded]');if(b)b.setAttribute('aria-expanded','false');});
      if(willOpen){wrap.classList.add('open');btn.setAttribute('aria-expanded','true');}
    });
  }
  wire('notifBtn','notifWrap');
  wire('acctBtn','acctWrap');

  function applyTabFilter(tabs){
    var activeBtn=tabs.querySelector('button.on[data-tab]');
    if(!activeBtn)return;
    var val=activeBtn.dataset.tab;
    var body=tabs.nextElementSibling;
    if(body){
      body.querySelectorAll('[data-tab-item]').forEach(function(it){
        it.style.display=(val==='all'||it.dataset.tabItem===val)?'':'none';
      });
    }
    var group=tabs.dataset.tabgroup;
    if(group){
      document.querySelectorAll('[data-tab-panel-group="'+group+'"]').forEach(function(p){
        p.classList.toggle('on',p.dataset.tabPanel===val);
      });
    }
  }
  document.querySelectorAll('.tabs').forEach(applyTabFilter);

  document.addEventListener('click',function(e){
    if(!e.target.closest('.hpop')){
      document.querySelectorAll('.hpop.open').forEach(function(w){w.classList.remove('open');var b=w.querySelector('[aria-expanded]');if(b)b.setAttribute('aria-expanded','false');});
    }
    var kbtn=e.target.closest('.kebab-btn');
    if(kbtn){
      e.preventDefault();e.stopPropagation();
      var wrap=kbtn.closest('.kebab');
      var willOpen=!wrap.classList.contains('open');
      document.querySelectorAll('.kebab.open').forEach(function(w){w.classList.remove('open');});
      if(willOpen)wrap.classList.add('open');
      return;
    }
    if(!e.target.closest('.kebab')){
      document.querySelectorAll('.kebab.open').forEach(function(w){w.classList.remove('open');});
    }
    var op=e.target.closest('[data-modal-open]');
    if(op){
      e.preventDefault();
      var m=document.getElementById(op.getAttribute('data-modal-open'));
      if(m)m.classList.add('open');
      return;
    }
    var cl=e.target.closest('[data-modal-close]');
    if(cl){
      e.preventDefault();
      var m2=cl.closest('.ac-modal');
      if(m2)m2.classList.remove('open');
      if(cl.id==='pub-submit')window.toast&&window.toast('Ressource publiée avec succès');
      if(cl.id==='pub-draft')window.toast&&window.toast('Enregistré en brouillon');
      if(cl.id==='live-submit')window.toast&&window.toast('Live planifié — vos apprenants seront notifiés');
      return;
    }
    var tabBtn=e.target.closest('.tabs button[data-tab]');
    if(tabBtn){
      var tabs=tabBtn.closest('.tabs');
      tabs.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b===tabBtn);});
      applyTabFilter(tabs);
      return;
    }
  });
  document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){
      document.querySelectorAll('.hpop.open').forEach(function(w){w.classList.remove('open');});
      document.querySelectorAll('.kebab.open').forEach(function(w){w.classList.remove('open');});
      document.querySelectorAll('.ac-modal.open').forEach(function(w){w.classList.remove('open');});
    }
  });
  var readAll=document.getElementById('notifReadAll');
  if(readAll)readAll.addEventListener('click',function(){
    document.querySelectorAll('.nt.unread').forEach(function(n){n.classList.remove('unread');});
    var bdg=document.querySelector('#notifBtn .bdg'); if(bdg) bdg.remove();
    window.toast&&window.toast('Notifications marquées comme lues');
  });
  var out=document.getElementById('acctLogout');
  if(out)out.addEventListener('click',function(e){e.preventDefault();window.location.href='Connexion.dc.html';});
})();
