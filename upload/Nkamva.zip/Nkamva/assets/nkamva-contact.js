/* NkamVa — Contact : soumission du formulaire (démo) */
(function(){
  const form = document.getElementById('cform');
  if(!form) return;
  form.addEventListener('submit', function(e){
    e.preventDefault();
    window.toast && toast('Message envoyé — écran hors du périmètre de cette refonte');
    form.reset();
  });
})();
