/* NkamVa — rendu partagé d'une carte ressource (.rc) — utilisé par catalogue & fiche */
(function(){
  const ARROW='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>';
  const HEART='<svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-9.8-9A5.6 5.6 0 0 1 12 6.3 5.6 5.6 0 0 1 21.8 12c-2.3 4.4-9.8 9-9.8 9z"/></svg>';
  function glyph(fmt){
    const stroke = fmt.svg==='stroke';
    return '<div class="glyph"><svg viewBox="0 0 24 24" '+(stroke?'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"':'fill="currentColor"')+'>'+fmt.glyph+'</svg></div>';
  }
  function stars(n){var f=Math.round(n);return '★★★★★'.slice(0,f)+'☆☆☆☆☆'.slice(0,5-f);}
  function isFav(kind,slug){try{return JSON.parse(localStorage.getItem('nk_fav_'+kind+'s')||'[]').indexOf(slug)!==-1;}catch(e){return false;}}
  window.NK_isFav = isFav;
  window.NK_glyph = glyph;
  window.NK_stars = stars;
  window.rcCard = function(r,i){
    return '<article class="rc" data-rv style="--i:'+((i||0)%8)+'">'
      +'<div class="cover '+r.category.cover+'"><span class="type">'+r.format.label.toUpperCase()+' · '+r.meta.toUpperCase()+'</span>'+glyph(r.format)
      +'<button class="fav'+(isFav('resource',r.slug)?' on':'')+'" data-slug="'+r.slug+'" data-kind="resource" aria-pressed="'+(isFav('resource',r.slug)?'true':'false')+'" aria-label="Ajouter aux favoris">'+HEART+'</button></div>'
      +'<div class="bd"><span class="chip '+r.category.chip+'">'+r.category.label+'</span>'
      +'<h3><a href="'+(window.NK_SPACE==='learner'?'Fiche ressource apprenant.dc.html':'Fiche ressource.dc.html')+'?r='+r.slug+'">'+r.title+'</a></h3>'
      +'<span class="auth"><span class="mini">'+r.author.initials+'</span>'+r.author.name+'</span>'
      +'<div class="ft"><span class="price">'+NKAMVA.fmtPrice(r.price)+'<small>FCFA</small></span><span class="go">Voir '+ARROW+'</span></div>'
      +'</div></article>';
  };
})();
