/* NkamVa — état d'achat partagé (mock) : communautés rejointes / ressources achetées en plus des données de démo, + modale de paiement réutilisable */
(function(){
  function getList(key){ try{ var l = JSON.parse(localStorage.getItem(key)); return Array.isArray(l)?l:[]; }catch(e){ return []; } }
  function addTo(key, val){ var l = getList(key); if(l.indexOf(val)===-1){ l.push(val); localStorage.setItem(key, JSON.stringify(l)); } return l; }

  var CLOSE_X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"></path></svg>';
  var CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';

  function ensureModal(){
    var m = document.getElementById('nk-checkout-modal');
    if(m) return m;
    m = document.createElement('div');
    m.className = 'ac-modal';
    m.id = 'nk-checkout-modal';
    m.innerHTML = '<div class="ac-modal-backdrop" id="nk-checkout-backdrop"></div><div class="ac-modal-card" id="nk-checkout-card"></div>';
    document.body.appendChild(m);
    document.getElementById('nk-checkout-backdrop').addEventListener('click', close);
    return m;
  }
  function open(html){ ensureModal(); document.getElementById('nk-checkout-card').innerHTML = '<button class="ac-modal-close" id="nk-checkout-x">'+CLOSE_X+'</button>'+html; document.getElementById('nk-checkout-modal').classList.add('open'); document.getElementById('nk-checkout-x').addEventListener('click', close); }
  function close(){ var m = document.getElementById('nk-checkout-modal'); if(m) m.classList.remove('open'); }

  var methods = [
    {id:'om', label:'Orange Money'},
    {id:'mtn', label:'MTN MoMo'},
    {id:'wave', label:'Wave'},
    {id:'cb', label:'Carte bancaire'}
  ];

  function openCheckout(opts){
    var method = 'om';
    function form(){
      return '<h3>'+opts.title+'</h3><p class="csub">'+opts.subtitle+'</p>'
        +'<div class="ac-rows" style="margin-bottom:16px"><div class="rm"><span>Montant</span><span>'+opts.priceLabel+'</span></div></div>'
        +'<div class="pay-methods">'+methods.map(function(m){ return '<button type="button" class="pay-m'+(m.id===method?' on':'')+'" data-m="'+m.id+'">'+m.label+'</button>'; }).join('')+'</div>'
        +'<div class="ac-modal-actions" style="margin-top:18px"><button class="btn btn-p" id="nk-checkout-pay">Payer '+opts.priceLabel+'</button></div>';
    }
    function success(){
      return '<div style="text-align:center;padding:10px 0">'
        +'<div style="width:56px;height:56px;border-radius:50%;background:var(--green-t);color:var(--green-d);display:grid;place-items:center;margin:0 auto 16px">'+CHECK+'</div>'
        +'<h3 style="margin-bottom:6px">Paiement réussi</h3><p class="csub" style="margin-bottom:22px">'+opts.successNote+'</p>'
        +'<div class="ac-modal-actions"><button class="btn btn-p" id="nk-checkout-continue">Continuer</button></div></div>';
    }
    open(form());
    var card = document.getElementById('nk-checkout-card');
    card.addEventListener('click', function handler(e){
      var m = e.target.closest('.pay-m'); if(m){ method = m.dataset.m; card.querySelectorAll('.pay-m').forEach(function(b){ b.classList.toggle('on', b===m); }); return; }
      if(e.target.closest('#nk-checkout-pay')){
        var btn = document.getElementById('nk-checkout-pay'); btn.textContent = 'Paiement en cours…'; btn.disabled = true;
        setTimeout(function(){
          card.innerHTML = success();
          document.getElementById('nk-checkout-continue').addEventListener('click', function(){ close(); if(opts.onSuccess) opts.onSuccess(); });
        }, 900);
        return;
      }
      if(e.target.closest('#nk-checkout-continue')){ close(); if(opts.onSuccess) opts.onSuccess(); }
    });
  }

  window.NK_PURCHASES = {
    isJoined: function(slug){ return (window.NK_JOINED_SLUGS||[]).indexOf(slug)!==-1 || getList('nk_extra_joined').indexOf(slug)!==-1; },
    joinCommunity: function(slug){ addTo('nk_extra_joined', slug); },
    extraJoined: function(){ return getList('nk_extra_joined'); },
    isPurchased: function(slug){ return getList('nk_extra_purchased').indexOf(slug)!==-1; },
    purchaseResource: function(slug){ addTo('nk_extra_purchased', slug); },
    extraPurchased: function(){ return getList('nk_extra_purchased'); },
    openCheckout: openCheckout
  };
})();
