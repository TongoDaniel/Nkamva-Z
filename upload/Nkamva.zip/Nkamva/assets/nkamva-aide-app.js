/* NkamVa — centre d'aide apprenant : recherche + accordéon (un seul ouvert) */
(function(){
  var search=document.getElementById('afsearch');
  var qas=Array.prototype.slice.call(document.querySelectorAll('.qa'));
  document.querySelectorAll('.atags button').forEach(function(b){
    b.addEventListener('click',function(){ if(search){ search.value=b.textContent; filter(); } });
  });
  function filter(){
    var q=search.value.trim().toLowerCase();
    qas.forEach(function(qa){
      var match=!q||qa.textContent.toLowerCase().indexOf(q)>-1;
      qa.style.display=match?'':'none';
    });
  }
  var t; if(search) search.addEventListener('input',function(){clearTimeout(t);t=setTimeout(filter,150);});
  qas.forEach(function(qa){
    var q=qa.querySelector('.q'), a=qa.querySelector('.a');
    q.setAttribute('aria-expanded','false');
    q.addEventListener('click',function(){
      var willOpen=!qa.classList.contains('open');
      qas.forEach(function(o){
        o.classList.remove('open');
        o.querySelector('.q').setAttribute('aria-expanded','false');
        o.querySelector('.a').style.maxHeight='0px';
      });
      if(willOpen){ qa.classList.add('open'); q.setAttribute('aria-expanded','true'); a.style.maxHeight=a.scrollHeight+'px'; }
    });
  });
})();
