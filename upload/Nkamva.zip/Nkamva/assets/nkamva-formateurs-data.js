/* NkamVa — données formateurs (dérivées des auteurs + de leur communauté unique) */
window.NKTRAIN = (function(){
  const since = {as:2024,dt:2025,yo:2023,mt:2024,km:2025,fn:2024,jk:2023};
  const order = ['as','dt','yo','mt','km','fn','jk'];
  const list = order.map(id=>{
    const a = NKAMVA.authors[id];
    const comm = NKCOMM.communities.find(c=>c.author.id===id);
    return Object.assign({}, a, {since: since[id], category: comm.category, community: comm});
  });
  function bySlug(id){return list.find(f=>f.id===id);}
  return {list, bySlug};
})();
