/* NkamVa — Tarifs : toggle mensuel/annuel + FAQ accordéon */
(function(){
  const btns = document.querySelectorAll('.pricetoggle button');
  const priceEl = document.getElementById('fprice');
  const noteEl = document.getElementById('fnote');
  btns.forEach(b=>b.addEventListener('click',()=>{
    btns.forEach(x=>x.classList.toggle('on',x===b));
    const annual = b.dataset.period==='annual';
    priceEl.innerHTML = annual ? '12 500<small>FCFA / mois</small>' : '15 000<small>FCFA / mois</small>';
    noteEl.textContent = annual ? '(annuel) \u00b7 soit 150 000 FCFA / an' : '';
  }));
  document.querySelectorAll('.faq .qa').forEach(qa=>{
    const q=qa.querySelector('.q'), a=qa.querySelector('.a');
    q.setAttribute('aria-expanded','false');
    q.addEventListener('click',()=>{
      const open=qa.classList.toggle('open');
      q.setAttribute('aria-expanded',open);
      a.style.maxHeight = open ? a.scrollHeight+'px' : '0px';
    });
  });
})();
