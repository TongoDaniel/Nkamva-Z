/* NkamVa — dashboard apprenant : popovers compte/notifications */
window.NK_SPACE = 'learner';
(function(){
  function wire(btnId,wrapId){
    var btn=document.getElementById(btnId), wrap=document.getElementById(wrapId);
    if(!btn||!wrap)return;
    btn.addEventListener('click',function(e){
      e.stopPropagation();
      var willOpen=!wrap.classList.contains('open');
      document.querySelectorAll('.hpop.open').forEach(function(w){w.classList.remove('open');w.querySelector('[aria-expanded]').setAttribute('aria-expanded','false');});
      if(willOpen){wrap.classList.add('open');btn.setAttribute('aria-expanded','true');}
    });
  }
  wire('notifBtn','notifWrap');
  wire('acctBtn','acctWrap');
  document.addEventListener('click',function(){
    document.querySelectorAll('.hpop.open').forEach(function(w){w.classList.remove('open');var b=w.querySelector('[aria-expanded]');if(b)b.setAttribute('aria-expanded','false');});
  });
  document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){document.querySelectorAll('.hpop.open').forEach(function(w){w.classList.remove('open');});}
  });
  var readAll=document.getElementById('notifReadAll');
  if(readAll)readAll.addEventListener('click',function(){
    document.querySelectorAll('.nt.unread').forEach(function(n){n.classList.remove('unread');});
    var bdg=document.querySelector('#notifBtn .bdg'); if(bdg) bdg.remove();
    window.toast&&window.toast('Notifications marquées comme lues');
  });
  var out=document.getElementById('acctLogout');
  if(out)out.addEventListener('click',function(e){e.preventDefault();window.location.href='Connexion.dc.html';});
})();
