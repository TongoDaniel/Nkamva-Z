/* NkamVa — jeu de données mock PARTAGÉ (réutilisé par catalogue, fiche, dashboard, formateur…) */
window.NKAMVA = (function(){
  const authors = {
    as:{id:'as',name:'Aminata Sow',initials:'AS',role:'Architecte logicielle',city:'Dakar, Sénégal',bio:"12 ans à concevoir des systèmes pour la fintech ouest-africaine. J'enseigne l'architecture comme un métier, pas comme une théorie.",rating:4.9,students:3120,resources:2},
    dt:{id:'dt',name:'Daniel Tongo',initials:'DT',role:'Lead QA & testeur',city:'Douala, Cameroun',bio:"Je traque les bugs pour les équipes produit depuis 8 ans. Mes guides sont des checklists nées du terrain.",rating:4.7,students:1440,resources:1},
    yo:{id:'yo',name:'Yann Ondoa',initials:'YO',role:'Monteur & créateur vidéo',city:'Yaoundé, Cameroun',bio:"430k abonnés cumulés. Je montre le montage tel que je le pratique, projet réel à l'appui.",rating:4.8,students:5210,resources:2},
    mt:{id:'mt',name:'Mariam Traoré',initials:'MT',role:'Juriste d\u2019affaires',city:'Bamako, Mali',bio:"J'accompagne les PME dans leur création et leur mise en conformité. Mes kits font gagner des semaines.",rating:4.9,students:980,resources:2},
    km:{id:'km',name:'Kwame Mensah',initials:'KM',role:'Consultant freelance & Notion',city:'Accra, Ghana',bio:"Freelance depuis 6 ans, je pilote tout dans Notion. Je partage mes systèmes, prêts à l'emploi.",rating:4.6,students:2260,resources:2},
    fn:{id:'fn',name:'Fatou Ndiaye',initials:'FN',role:'Consultante SEO & growth',city:'Abidjan, Côte d\u2019Ivoire',bio:"J'aide les commerces locaux à être trouvés sur Google. Résultats mesurables, méthodes simples.",rating:4.8,students:1870,resources:2},
    jk:{id:'jk',name:'Jean-Marc Kouassi',initials:'JK',role:'Product designer',city:'Abidjan, Côte d\u2019Ivoire',bio:"Designer produit dans la tech africaine. J'enseigne l'UI par la pratique, un projet à la fois.",rating:4.9,students:4090,resources:2},
  };

  const categories = [
    {id:'dev',label:'Développement',chip:'',cover:'dev'},
    {id:'biz',label:'Business',chip:'chip-clay',cover:'biz'},
    {id:'dsg',label:'Design',chip:'chip-blue',cover:'dsg'},
    {id:'mkt',label:'Marketing',chip:'chip-gold',cover:'mkt'},
  ];

  const formats = {
    video:{label:'Vidéo',glyph:'<path d="M8 5v14l11-7z"/>',svg:'fill'},
    pdf:{label:'PDF',glyph:'<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5"/>',svg:'stroke'},
    kit:{label:'Kit',glyph:'<path d="M12 3 3 8l9 5 9-5-9-5z"/><path d="M3 13l9 5 9-5M3 18l9 5 9-5"/>',svg:'stroke'},
    notion:{label:'Modèle',glyph:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 10h16M10 10v10"/>',svg:'stroke'},
    tableur:{label:'Tableur',glyph:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M3 14h18M9 4v16M15 4v16"/>',svg:'stroke'},
  };

  // meta = format label affiché (durée / pages), fmt = clé format, cat = clé catégorie
  const resources = [
    {slug:'architecture-logicielle-ddd',title:'Architecture logicielle — masterclass Patterns & DDD',cat:'dev',fmt:'video',meta:'4 h 20',price:49000,author:'as',rating:4.9,reviews:214,students:1280,level:'Avancé',updated:'Mars 2026',lang:'Français',
      blurb:"Concevez des systèmes qui tiennent la charge et le temps. Patterns tactiques, Domain-Driven Design et découpage en services, appliqués à des cas réels.",
      learn:['Modéliser un domaine métier avec DDD','Choisir le bon pattern selon le contexte','Découper un monolithe en services cohérents','Poser des frontières et des contrats clairs'],
      includes:['4 h 20 de vidéo HD','Code source des exemples','Diagrammes téléchargeables','Accès à vie, mises à jour incluses']},
    {slug:'guide-qa-checklist',title:'Guide QA — Checklist de validation fonctionnelle',cat:'dev',fmt:'pdf',meta:'24 pages',price:1000,author:'dt',rating:4.7,reviews:88,students:640,level:'Débutant',updated:'Février 2026',lang:'Français',
      blurb:"La checklist que j'utilise avant chaque mise en production. Rien à installer : imprimez, cochez, livrez sereinement.",
      learn:['Structurer une recette fonctionnelle','Repérer les cas limites oubliés','Documenter un bug utile pour les devs','Prioriser ce qui bloque vraiment'],
      includes:['24 pages PDF prêtes à imprimer','Modèle de fiche de bug','Accès à vie']},
    {slug:'montage-davinci-resolve',title:'Montage vidéo avec DaVinci Resolve — de zéro à publié',cat:'dsg',fmt:'video',meta:'2 h 05',price:3000,author:'yo',rating:4.8,reviews:301,students:2140,level:'Débutant',updated:'Janvier 2026',lang:'Français',
      blurb:"Du rush brut à la vidéo publiée, sans jargon. On monte un projet réel ensemble, étape par étape, sur la version gratuite de DaVinci.",
      learn:['Maîtriser l\u2019interface de DaVinci Resolve','Couper, rythmer et raccorder proprement','Étalonner et corriger le son','Exporter pour YouTube et le mobile'],
      includes:['2 h 05 de vidéo','Rushes du projet fil rouge','LUT et presets d\u2019export','Accès à vie']},
    {slug:'lancer-sa-pme-kit',title:'Lancer sa PME — kit juridique & financier complet',cat:'biz',fmt:'kit',meta:'PDF + tableur',price:6900,author:'mt',rating:4.9,reviews:126,students:520,level:'Intermédiaire',updated:'Mars 2026',lang:'Français',
      blurb:"Toutes les pièces pour créer et piloter votre PME dans l'espace OHADA : statuts, prévisionnel, suivi de trésorerie. Prêt à remplir.",
      learn:['Choisir la bonne forme juridique','Bâtir un prévisionnel crédible','Suivre sa trésorerie mois par mois','Éviter les erreurs de conformité courantes'],
      includes:['Modèles de statuts (Word)','Tableur prévisionnel & trésorerie','Guide PDF de 40 pages','Accès à vie, mises à jour incluses']},
    {slug:'notion-freelances',title:'Notion pour freelances — pilotez missions & factures',cat:'biz',fmt:'notion',meta:'Modèle Notion',price:4500,author:'km',rating:4.6,reviews:174,students:1310,level:'Débutant',updated:'Février 2026',lang:'Français',
      blurb:"Mon système Notion complet pour gérer clients, missions, factures et revenus au même endroit. Dupliquez-le et travaillez dès aujourd'hui.",
      learn:['Centraliser clients et missions','Suivre devis, factures et paiements','Visualiser vos revenus mensuels','Adapter le système à votre activité'],
      includes:['Modèle Notion à dupliquer','Vidéo de prise en main (18 min)','Mises à jour à vie']},
    {slug:'seo-local-commerce',title:'SEO local — faire trouver son commerce sur Google',cat:'mkt',fmt:'video',meta:'3 h 10',price:8000,author:'fn',rating:4.8,reviews:142,students:890,level:'Intermédiaire',updated:'Janvier 2026',lang:'Français',
      blurb:"Faites remonter votre commerce dans Google et sur la carte. Une méthode locale, testée sur des dizaines d'entreprises africaines.",
      learn:['Optimiser sa fiche Google Business','Choisir les bons mots-clés locaux','Récolter des avis qui convertissent','Mesurer ce qui ramène des clients'],
      includes:['3 h 10 de vidéo','Modèle de fiche Google','Checklist SEO local','Accès à vie']},
    {slug:'ui-design-fondamentaux',title:'UI design — les fondamentaux, projet par projet',cat:'dsg',fmt:'video',meta:'5 h 40',price:12000,author:'jk',rating:4.9,reviews:268,students:2010,level:'Débutant',updated:'Mars 2026',lang:'Français',
      blurb:"Apprenez le design d'interface en concevant de vrais écrans. Typographie, couleur, grilles et composants — la théorie juste ce qu'il faut.",
      learn:['Poser une hiérarchie visuelle claire','Composer typographie et couleur','Construire une grille et des espacements','Livrer des maquettes propres dans Figma'],
      includes:['5 h 40 de vidéo','Fichiers Figma des projets','Kit UI de démarrage','Accès à vie, mises à jour incluses']},
    {slug:'whatsapp-business-auto',title:'Automatiser WhatsApp Business — répondre en dormant',cat:'mkt',fmt:'pdf',meta:'18 pages',price:2500,author:'fn',rating:4.5,reviews:63,students:410,level:'Débutant',updated:'Février 2026',lang:'Français',
      blurb:"Mettez en place des réponses automatiques, un catalogue et un tunnel de vente sur WhatsApp Business, sans coder.",
      learn:['Configurer les réponses automatiques','Monter un catalogue produit','Créer des messages de relance','Suivre les conversations qui vendent'],
      includes:['Guide PDF de 18 pages','Modèles de messages prêts','Accès à vie']},
    {slug:'python-data-debutant',title:'Python pour l\u2019analyse de données — premiers pas',cat:'dev',fmt:'video',meta:'6 h 15',price:15000,author:'as',rating:4.8,reviews:97,students:720,level:'Débutant',updated:'Mars 2026',lang:'Français',
      blurb:"De zéro à vos premières analyses réelles avec Python, pandas et des jeux de données africains concrets.",
      learn:['Écrire ses premiers scripts Python','Manipuler des tableaux avec pandas','Nettoyer et croiser des données','Produire des graphiques lisibles'],
      includes:['6 h 15 de vidéo','Notebooks et jeux de données','Exercices corrigés','Accès à vie']},
    {slug:'branding-identite-visuelle',title:'Identité visuelle — créer une marque qui reste',cat:'dsg',fmt:'kit',meta:'Vidéo + gabarits',price:9500,author:'jk',rating:4.7,reviews:81,students:530,level:'Intermédiaire',updated:'Janvier 2026',lang:'Français',
      blurb:"Logo, palette, typographie, déclinaisons : construisez une identité de marque cohérente et livrez un guide de style pro.",
      learn:['Traduire une marque en éléments visuels','Composer une palette et une typo durables','Décliner un logo sur tous les supports','Livrer un guide de style clair'],
      includes:['2 h 40 de vidéo','Gabarits de charte (Figma)','Bibliothèque d\u2019icônes','Accès à vie']},
    {slug:'compta-simplifiee-tableur',title:'Comptabilité simplifiée — le tableur tout-en-un',cat:'biz',fmt:'tableur',meta:'Tableur + guide',price:3500,author:'mt',rating:4.8,reviews:110,students:940,level:'Débutant',updated:'Février 2026',lang:'Français',
      blurb:"Suivez recettes, dépenses et TVA sans logiciel comptable. Un tableur clair, pensé pour les indépendants et petites structures.",
      learn:['Enregistrer recettes et dépenses','Suivre sa marge en temps réel','Préparer ses déclarations','Anticiper sa trésorerie'],
      includes:['Tableur prêt à l\u2019emploi','Guide PDF de prise en main','Accès à vie, mises à jour incluses']},
    {slug:'react-projet-reel',title:'React en pratique — construire une vraie application',cat:'dev',fmt:'video',meta:'7 h 30',price:18000,author:'dt',rating:4.7,reviews:134,students:610,level:'Intermédiaire',updated:'Mars 2026',lang:'Français',
      blurb:"On construit une application complète en React, du composant à la mise en ligne. State, routing, appels API : tout par la pratique.",
      learn:['Structurer une application React','Gérer l\u2019état et les effets','Consommer une API proprement','Déployer en production'],
      includes:['7 h 30 de vidéo','Code source par étape','Accès à vie']},
    {slug:'photographie-smartphone',title:'Photographie au smartphone — des images qui vendent',cat:'dsg',fmt:'video',meta:'2 h 45',price:5000,author:'yo',rating:4.6,reviews:76,students:820,level:'Débutant',updated:'Janvier 2026',lang:'Français',
      blurb:"Prenez des photos produit et lifestyle dignes d'un pro, avec le téléphone que vous avez déjà. Lumière, cadrage, retouche mobile.",
      learn:['Maîtriser la lumière naturelle','Cadrer et composer une photo produit','Retoucher sur mobile en 5 minutes','Créer un feed cohérent'],
      includes:['2 h 45 de vidéo','Presets de retouche mobile','Accès à vie']},
    {slug:'publicite-facebook-instagram',title:'Publicité Facebook & Instagram — le guide qui convertit',cat:'mkt',fmt:'video',meta:'4 h 00',price:11000,author:'fn',rating:4.7,reviews:119,students:700,level:'Intermédiaire',updated:'Février 2026',lang:'Français',
      blurb:"Lancez des campagnes qui rapportent, sans brûler votre budget. Ciblage, créa, tunnel et lecture des chiffres.",
      learn:['Structurer une campagne rentable','Cibler la bonne audience','Créer des visuels qui arrêtent le scroll','Lire ses résultats et optimiser'],
      includes:['4 h de vidéo','Modèles de visuels','Tableur de suivi budget','Accès à vie']},
    {slug:'gestion-projet-agile',title:'Gestion de projet agile — livrer sans chaos',cat:'biz',fmt:'pdf',meta:'32 pages',price:4000,author:'km',rating:4.6,reviews:58,students:480,level:'Intermédiaire',updated:'Mars 2026',lang:'Français',
      blurb:"Les rituels et outils agiles expliqués simplement, pour des équipes qui livrent vraiment. Sans dogme, avec du bon sens.",
      learn:['Cadrer un projet et son périmètre','Animer les rituels essentiels','Prioriser un backlog utile','Suivre l\u2019avancement sans réunionite'],
      includes:['Guide PDF de 32 pages','Modèles de backlog & rétro','Accès à vie']},
    {slug:'design-system-figma',title:'Design system dans Figma — composants & tokens',cat:'dsg',fmt:'video',meta:'3 h 55',price:14000,author:'jk',rating:4.9,reviews:92,students:560,level:'Avancé',updated:'Mars 2026',lang:'Français',
      blurb:"Construisez un design system maintenable dans Figma : tokens, composants, variantes et documentation que les devs adorent.",
      learn:['Structurer des tokens de design','Créer des composants à variantes','Documenter pour le handoff','Faire évoluer le système sans tout casser'],
      includes:['3 h 55 de vidéo','Fichier Figma de démarrage','Accès à vie, mises à jour incluses']},
  ];

  // enrichit chaque ressource (curriculum + avis générés de façon cohérente)
  const firstNames=['Awa','Ibrahim','Grace','Cheikh','Nadège','Serge','Fadila','Olivier','Rokhaya','Patrick'];
  const reviewBits=[
    "Exactement ce que je cherchais, sans blabla. Chaque partie sert.",
    "Le formateur va droit au but et les exemples parlent vraiment.",
    "J'ai appliqué dès le lendemain, résultats concrets. Prix largement justifié.",
    "Clair, bien rythmé, accessible même en partant de zéro.",
    "Un des rares contenus adaptés à notre contexte. Merci !",
    "Rien à jeter. J'y reviens régulièrement comme référence.",
  ];
  function seeded(n){let s=n*9301+49297;return function(){s=(s*9301+49297)%233280;return s/233280;};}
  resources.forEach((r,idx)=>{
    r.author = authors[r.author];
    r.category = categories.find(c=>c.id===r.cat);
    r.format = formats[r.fmt];
    const rand=seeded(idx+3);
    // curriculum
    const nMod = r.fmt==='pdf'||r.fmt==='tableur'||r.fmt==='notion' ? 3 : 4+Math.floor(rand()*2);
    r.curriculum=[];
    const modTitles=['Prise en main & fondations','Le cœur du sujet, en pratique','Aller plus loin, cas réels','Finaliser, livrer & progresser','Bonus & modèles réutilisables'];
    for(let m=0;m<nMod;m++){
      const nl=3+Math.floor(rand()*3);
      r.curriculum.push({title:modTitles[m]||('Module '+(m+1)),lessons:nl,mins:nl*(8+Math.floor(rand()*12))});
    }
    r.lessonsTotal = r.curriculum.reduce((a,c)=>a+c.lessons,0);
    // avis
    r.reviewList=[];
    for(let i=0;i<3;i++){
      const stars = rand()>0.25?5:4;
      r.reviewList.push({name:firstNames[(idx*3+i)%firstNames.length],initials:firstNames[(idx*3+i)%firstNames.length].slice(0,2).toUpperCase(),stars,text:reviewBits[(idx*2+i)%reviewBits.length]});
    }
    // note distribution
    r.dist=[Math.round(r.reviews*0.72),Math.round(r.reviews*0.19),Math.round(r.reviews*0.06),Math.round(r.reviews*0.02),Math.round(r.reviews*0.01)];
  });

  function fmtPrice(n){return n.toLocaleString('fr-FR').replace(/\u202f/g,' ');}
  function bySlug(s){return resources.find(r=>r.slug===s);}
  // recalcule le nombre réel de ressources par formateur (source de vérité = le catalogue)
  Object.values(authors).forEach(a=>{ a.resources = resources.filter(r=>r.author===a).length; });

  return {resources,authors,categories,formats,fmtPrice,bySlug};
})();
