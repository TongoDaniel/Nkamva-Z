/* NkamVa — fiche communauté : rend le détail depuis ?c=slug */
(function(){
  const slug = new URLSearchParams(location.search).get('c');
  const c = NKCOMM.bySlug(slug) || NKCOMM.communities[0];
  document.title = c.name + ' — NkamVa';
  const a = c.author;

  const joined = window.NK_SPACE==='learner' && window.NK_PURCHASES && NK_PURCHASES.isJoined(c.slug);
  document.getElementById('crumbtop').innerHTML =
    '<a href="'+(window.NK_SPACE==='learner'?'Communautés apprenant.dc.html':'Communautes.dc.html')+'">'+(joined?'Mes communautés':'Communautés')+'</a><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg><span>'+c.name+'</span>';

  document.getElementById('chead').innerHTML =
    '<div class="chead2"><div class="cav2">'+a.initials+'</div><div><h1>'+c.name+'<span class="status">Active</span></h1>'
    +'<span class="canim">Animée par <b>'+a.name+'</b> · '+a.role+'</span></div></div>';

  document.getElementById('cstats').innerHTML =
    '<div class="st"><b>'+c.members.toLocaleString('fr-FR')+'</b><span>membres</span></div>'
    +'<div class="st"><b>'+NKCOMM.salons.length+'</b><span>salons</span></div>'
    +'<div class="st"><b>'+c.messages+'</b><span>messages / jour</span></div>'
    +'<div class="st"><b>'+c.lives+'</b><span>lives / mois</span></div>';

  const GO='<svg class="sgo" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>';
  const salonTag = (s)=>'<div class="sic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+s.icon+'</svg></div><div><h4>'+s.label+'</h4><p>'+s.desc+'</p></div>'+GO;
  const salons = NKCOMM.salons.map(s=>'<button type="button" class="salon" data-view="'+s.key+'">'+salonTag(s)+'</button>').join('');

  const BACK='<button class="cback" type="button" id="cback"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m15 6-6 6 6 6"/></svg>Retour à la communauté</button>';
  const CK='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';

  function homeView(){
    return '<section class="csec"><h2>À propos de cette communauté</h2><p>'+c.desc+'</p>'
      +'<div class="trailer"><button class="playbtn" aria-label="Voir le trailer"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button><span class="tag">Trailer · 1 min 30</span></div></section>'
      +'<section class="csec"><h2>Salons de la communauté</h2><div class="salons">'+salons+'</div></section>';
  }

  function forumKey(){ return 'nk_forum_'+c.slug; }
  function forumPosts(){
    let posts;
    try{ posts = JSON.parse(localStorage.getItem(forumKey())); }catch(e){ posts = null; }
    if(!Array.isArray(posts)){
      posts = [{name:a.name,init:a.initials,when:"il y a 2 j",text:"Bienvenue dans "+c.name+" ! Postez vos questions ici, je réponds sous 24h."}];
    }
    return posts;
  }
  function postCard(p){
    return '<div class="fpost"><span class="ava sm">'+p.init+'</span><div class="fpost-tx"><b>'+p.name+'</b><small>'+p.when+'</small><p>'+p.text+'</p></div></div>';
  }
  function forumView(){
    const posts = forumPosts();
    return BACK+'<section class="csec"><h2>Forum</h2><p class="csub">Échanges et questions de la communauté.</p>'
      +'<div class="fcard fcompose"><span class="ava sm">DL</span><div class="fcompose-in"><textarea id="fmsg" rows="1" placeholder="Partagez une question, une victoire, une ressource…"></textarea><button class="btn btn-p btn-sm" id="fsend">Publier</button></div></div>'
      +'<div class="fposts" id="fposts">'+posts.map(postCard).join('')+'</div></section>';
  }

  function liveCard(item){
    return '<div class="fcard livecard2"><div class="live-date"><b>'+item.day+'</b><span>'+item.dow+'</span></div>'
      +'<div class="fpost-tx"><b>'+item.title+'</b><small>'+item.meta+'</small></div>'
      +'<a class="btn btn-o btn-sm'+(item.href?'':' soon')+'" href="'+(item.href||'#')+'">'+item.cta+'</a></div>';
  }
  function livesView(){
    const next = c.lives>0 ? liveCard({day:'23',dow:'Jeu',title:'Live — session avec '+a.name,meta:c.name+' · 18h00 UTC',cta:'Voir'}) : '<p class="csub">Aucun live prévu pour le moment.</p>';
    const n = Math.max(0,c.lives);
    const replays = Array.from({length:n}).map((_,i)=>liveCard({day:16-i*7,dow:'Jeu',title:'Replay — session #'+(n-i),meta:c.name,cta:'Regarder',href:'Replay.dc.html'})).join('');
    return BACK+'<section class="csec"><h2>Lives &amp; Replays</h2>'
      +'<p class="csub" style="margin:14px 0 10px">Prochaine session</p>'+next
      +(replays?'<p class="csub" style="margin:22px 0 10px">Replays</p>'+replays:'')+'</section>';
  }

  const DOC_ICON='<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/>';
  function resCard(r){
    return '<div class="mr-card"><div class="mr-thumb" style="background:var(--green-t);color:var(--green-d)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+DOC_ICON+'</svg></div>'
      +'<div class="mr-tx"><span class="rc-type">'+r.type+'</span><h3>'+r.title+'</h3><p>'+r.desc+'</p></div>'
      +'<div class="mr-actions"><button class="btn btn-o btn-sm" data-act="consult" data-title="'+r.title+'" data-type="'+r.type+'" data-desc="'+r.desc+'">Consulter</button></div></div>';
  }
  function resourcesView(){
    const items = (window.NK_COMM_RES && window.NK_COMM_RES[c.slug]) || [];
    return BACK+'<section class="csec"><h2>Ressources de la communauté</h2><p class="csub">Incluses avec votre abonnement — pas de vente à l\u2019unité.</p>'
      +(items.length ? '<div class="mr-list" style="margin-top:16px">'+items.map(resCard).join('')+'</div>' : '<p class="csub" style="margin-top:16px">Aucune ressource partagée pour le moment.</p>')
      +'</section>';
  }

  function renderView(v){
    const main = document.getElementById('cmain');
    if(v==='forum') main.innerHTML = forumView();
    else if(v==='live') main.innerHTML = livesView();
    else if(v==='res') main.innerHTML = resourcesView();
    else main.innerHTML = homeView();
  }
  renderView('home');

  document.getElementById('cmain').addEventListener('click', e=>{
    const back = e.target.closest('#cback'); if(back){ renderView('home'); return; }
    const s = e.target.closest('.salon[data-view]'); if(s){
      if(!joined){ toast('Rejoignez la communauté pour accéder à ce salon'); return; }
      renderView(s.dataset.view);
      return;
    }
    if(e.target.closest('#fsend')){
      const ta = document.getElementById('fmsg'); const text = ta.value.trim(); if(!text) return;
      const posts = forumPosts();
      posts.unshift({name:'Daniel Learner Test',init:'DL',when:"à l'instant",text});
      localStorage.setItem(forumKey(), JSON.stringify(posts));
      document.getElementById('fposts').innerHTML = posts.map(postCard).join('');
      ta.value=''; toast('Publié dans le forum');
    }
    const cons = e.target.closest('[data-act="consult"]'); if(cons){
      const d = cons.dataset;
      openResModal('<h3>'+d.title+'</h3><p class="csub">'+c.name+' · '+d.type+'</p>'
        +'<span class="chip" style="margin:2px 0 18px">Inclus avec l\u2019abonnement</span>'
        +'<p style="font-size:14px;color:var(--ink2);line-height:1.6;margin:0 0 24px">'+d.desc+'</p>'
        +'<div class="ac-modal-actions"><button class="btn btn-p" data-act="dl">Télécharger</button></div>');
    }
  });

  const resModal = document.getElementById('res-modal'), resModalCard = document.getElementById('res-modal-card');
  const CLOSE_X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"></path></svg>';
  function openResModal(html){ resModalCard.innerHTML = '<button class="ac-modal-close" id="res-modal-x">'+CLOSE_X+'</button>'+html; resModal.classList.add('open'); }
  function closeResModal(){ resModal.classList.remove('open'); }
  if(resModal){
    document.getElementById('res-modal-backdrop').addEventListener('click', closeResModal);
    resModalCard.addEventListener('click', e=>{ if(e.target.closest('#res-modal-x')) closeResModal(); else if(e.target.closest('[data-act="dl"]')) toast('Téléchargement lancé'); });
  }

  const sidePanel = joined
    ? '<div class="pr"><span class="ownedtag">'+CK+'Vous êtes membre</span></div>'
      +'<a class="btn btn-p btn-lg" href="Messagerie.dc.html">Contacter le formateur</a>'
      +'<div class="guarantee"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>Accès complet aux salons de la communauté</div>'
    : '<div class="pr"><span class="price">'+NKAMVA.fmtPrice(c.price)+'<small>FCFA / mois</small></span></div><p class="once">Intégration mensuelle · résiliable à tout moment</p>'
      +'<button class="btn btn-p btn-lg" id="joinbtn">Rejoindre la communauté</button>'
      +'<div class="guarantee"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>Accès immédiat après paiement</div>'
      +'<ul class="blist"><li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>Forum et messagerie avec l\u2019animateur</li>'
      +'<li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>Ressources exclusives de la communauté</li>'
      +'<li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>Lives mensuels + replays illimités</li></ul>'
      +'<div class="paynote"><span class="pp dark h22"><img src="assets/pay/orange-money.svg" alt="Orange Money"></span><span class="pp mtn"><img src="assets/pay/mtn.svg" alt="MTN MoMo"></span><span class="pp"><img src="assets/pay/wave.png" alt="Wave" class="h22"></span><span>+ carte bancaire</span></div>';

  document.getElementById('cside').innerHTML =
    '<div class="memberbox"><h4>Membres</h4><div class="mstack">'+(function(){
      const sample=['AK','FB','NR','SD','TM'];
      const shown=Math.min(5,c.members||0);
      let h=sample.slice(0,shown).map(i=>'<span>'+i+'</span>').join('');
      if(c.members>shown) h+='<span class="more">+'+(c.members-shown).toLocaleString('fr-FR')+'</span>';
      return h;
    })()+'</div><p class="mnote">'+c.members.toLocaleString('fr-FR')+' membre'+(c.members>1?'s':'')+' déjà inscrits.</p></div>'
    +'<div class="buybox"><div class="bd">'+sidePanel+'</div></div>';

  const jb = document.getElementById('joinbtn');
  if (jb) jb.addEventListener('click', ()=>{
    if(!window.NK_PURCHASES) return;
    NK_PURCHASES.openCheckout({
      title: c.name,
      subtitle: 'Abonnement mensuel · '+a.name,
      priceLabel: NKAMVA.fmtPrice(c.price)+' FCFA',
      successNote: 'Vous avez rejoint '+c.name+'.',
      onSuccess: function(){ NK_PURCHASES.joinCommunity(c.slug); toast('Bienvenue dans '+c.name+' !'); location.reload(); }
    });
  });
})();
