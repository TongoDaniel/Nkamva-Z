/* NkamVa — carte formateur (.tc) listing */
(function(){
  window.trainerCard = function(f,i){
    return '<article class="tc" data-rv style="--i:'+((i||0)%8)+'">'
      +'<div class="tav">'+f.initials+'</div>'
      +'<h3><a href="'+(window.NK_SPACE==='learner'?'Formateur apprenant.dc.html':'Formateur.dc.html')+'?f='+f.id+'">'+f.name+'</a></h3>'
      +'<p class="trole">'+f.role+'</p>'
      +'<div class="tstats"><span><b>'+f.resources+'</b> ressource'+(f.resources>1?'s':'')+'</span><span><b>'+f.students.toLocaleString('fr-FR')+'</b> apprenants</span></div>'
      +'<span class="btn btn-o btn-sm" style="pointer-events:none">Voir le profil</span>'
      +'</article>';
  };
})();
