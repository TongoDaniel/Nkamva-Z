/* NkamVa — session live (apprenant) : salle d'attente, live actif, chat/participants/notes */
(function(){
  var ICON = {
    exit:'<path d="M15 3h3.5A2.5 2.5 0 0 1 21 5.5v13a2.5 2.5 0 0 1-2.5 2.5H15"></path><path d="M10 16l5-4-5-4"></path><path d="M15 12H3"></path>',
    bell:'<path d="M6 8a6 6 0 0 1 12 0c0 3.2 1 5 2 6.5H4C5 13 6 11.2 6 8Z"></path><path d="M9.5 18a2.5 2.5 0 0 0 5 0"></path>',
    mic:'<path d="M12 2a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V5a3 3 0 0 1 3-3Z"></path><path d="M19 10v1a7 7 0 0 1-14 0v-1"></path><path d="M12 18v4"></path><path d="M8 22h8"></path>',
    micOff:'<path d="M12 2a3 3 0 0 1 3 3v6a3 3 0 0 1-.4 1.5"></path><path d="M9 9V5a3 3 0 0 1 5-2.2"></path><path d="M19 10v1a7 7 0 0 1-1 3.6"></path><path d="M5 10v1a7 7 0 0 0 11.7 5.1"></path><path d="M12 18v4"></path><path d="M8 22h8"></path><path d="M3 3l18 18"></path>',
    cam:'<rect x="3" y="6" width="12" height="12" rx="2.5"></rect><path d="m21 8-6 4 6 4V8Z"></path>',
    camOff:'<rect x="3" y="6" width="12" height="12" rx="2.5"></rect><path d="m21 8-6 4 6 4V8Z"></path><path d="M2 2l20 20"></path>',
    hand:'<path d="M9 12.5V5a1.5 1.5 0 0 1 3 0v6"></path><path d="M12 11V4a1.5 1.5 0 0 1 3 0v7"></path><path d="M15 11.5V7a1.5 1.5 0 0 1 3 0v7"></path><path d="M18 14v-1a1.5 1.5 0 0 1 3 0v4c0 3.3-2.2 6-6 6h-1.5c-2.4 0-3.7-.8-5-2.6L6 16.8c-.6-.9-.3-1.8.5-2.3.8-.5 1.7-.2 2.3.5L9 15.8"></path>',
    chat:'<path d="M21 11.5a8.38 8.38 0 0 1-9 8.4A8.5 8.5 0 1 1 20.9 9a8.4 8.4 0 0 1 .1 2.5Z"></path>',
    users:'<circle cx="9" cy="8" r="3.2"></circle><path d="M3.5 19c0-3 2.5-5 5.5-5s5.5 2 5.5 5"></path><path d="M15.5 5.5A3.2 3.2 0 0 1 17 11.6"></path><path d="M20.5 19c0-2.4-1.6-4.3-3.8-4.8"></path>',
    notes:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"></path><path d="M9 7h7M9 11h7M9 15h4"></path>',
    close:'<path d="M6 6l12 12M18 6 6 18"></path>',
    send:'<path d="M22 2 11 13"></path><path d="M22 2 15 22l-4-9-9-4z"></path>',
    signal:'<rect x="3" y="12" width="3" height="7" fill="currentColor" stroke="none" rx="1"></rect><rect x="9" y="8" width="3" height="11" fill="currentColor" stroke="none" rx="1"></rect><rect x="15" y="4" width="3" height="15" fill="currentColor" stroke="none" rx="1"></rect>'
  };
  function svg(name,extra){ return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" '+(extra||'')+'>'+ICON[name]+'</svg>'; }

  var session = {
    title:'Live — revue de checklists QA',
    community:'QA & Tests logiciels',
    formateur:'Daniel Tongo',
    initials:'DT',
    dateLabel:'jeudi 23 juillet 2026 · 18h00 UTC',
    replayHref:'Replay.dc.html'
  };

  var shell = document.getElementById('live-shell');
  if(!shell) return;

  var state = 'pending'; // pending | live
  var target = Date.now() + (2*24*3600 + 5*3600 + 12*60)*1000;
  var micOn = true, camOn = true, handRaised = false;
  var remindKey = 'nk_live_remind';
  var notesKey = 'nk_live_notes';
  var activePanel = null; // chat | participants | notes

  function renderPending(){
    shell.innerHTML =
      '<div class="replay-top">'+
        '<div class="rid"><img class="mki" src="assets/img/mark.svg" alt=""><div><div style="display:flex;align-items:center;gap:10px"><span class="replay-badge" style="background:var(--blue)">PLANIFIÉ</span><h1>'+session.title+'</h1></div><p class="replay-sub">'+session.community+' · '+session.dateLabel+'</p></div></div>'+
        '<a class="replay-quit" href="Mes lives.dc.html">'+svg('exit')+'Quitter</a>'+
      '</div>'+
      '<div class="live-pending">'+
        '<div class="live-pending-ava">'+session.initials+'</div>'+
        '<h2>'+session.formateur+'</h2>'+
        '<p>Le live démarre '+session.dateLabel+'</p>'+
        '<div class="live-countdown" id="lc-countdown"></div>'+
        '<div class="live-pending-actions">'+
          '<button class="live-remind" id="lc-remind">'+svg('bell')+'<span>Activer un rappel</span></button>'+
          '<button class="live-preview-link" id="lc-preview">Voir un aperçu de l\u2019interface en direct →</button>'+
        '</div>'+
      '</div>'+
      '<p class="live-chat-locked">Le chat ouvrira au démarrage du live.</p>';

    var remindOn = localStorage.getItem(remindKey)==='1';
    var rbtn = document.getElementById('lc-remind');
    function paintRemind(){ rbtn.classList.toggle('on', remindOn); rbtn.querySelector('span').textContent = remindOn ? 'Rappel activé' : 'Activer un rappel'; }
    paintRemind();
    rbtn.addEventListener('click', function(){ remindOn = !remindOn; localStorage.setItem(remindKey, remindOn?'1':'0'); paintRemind(); toast(remindOn?'Rappel activé — vous serez notifié 15 min avant':'Rappel désactivé'); });
    document.getElementById('lc-preview').addEventListener('click', function(){ state='live'; renderLive(); });

    function tick(){
      var diff = Math.max(0, target - Date.now());
      var d = Math.floor(diff/86400000), h = Math.floor(diff%86400000/3600000), m = Math.floor(diff%3600000/60000), s = Math.floor(diff%60000/1000);
      document.getElementById('lc-countdown').innerHTML = [
        [d,'Jours'],[h,'Heures'],[m,'Min'],[s,'Sec']
      ].map(function(p){ return '<div class="cd"><b>'+(p[0]<10?'0':'')+p[0]+'</b><span>'+p[1]+'</span></div>'; }).join('');
    }
    tick();
    var timer = setInterval(function(){ if(state!=='pending'){ clearInterval(timer); return; } tick(); }, 1000);
  }

  var chatMsgs = [];
  var elapsed = 0, elapsedTimer;

  function renderLive(){
    shell.innerHTML =
      '<div class="replay-top">'+
        '<div class="rid"><img class="mki" src="assets/img/mark.svg" alt=""><div><div style="display:flex;align-items:center;gap:10px"><span class="replay-badge live">EN DIRECT</span><h1>'+session.title+'</h1><span class="replay-sub" id="lc-elapsed" style="margin:0">00:00</span></div><p class="replay-sub">'+session.community+'</p></div></div>'+
        '<a class="replay-quit" href="Mes lives.dc.html">'+svg('exit')+'Quitter</a>'+
      '</div>'+
      '<div class="live-body">'+
        '<div class="live-stage">'+
          '<div class="live-grid">'+
            '<div class="live-tile" id="tile-you"><span class="lt-tag" id="you-tag">'+svg('mic')+'Daniel Learner Test (vous)</span></div>'+
            '<div class="live-tile speaking"><span class="lt-role">Formateur</span><span class="lt-tag">'+svg('mic')+session.formateur+'</span><span class="lt-signal">'+svg('signal')+'</span></div>'+
          '</div>'+
          '<div class="live-controls-bar">'+
            '<button id="ctl-mic" title="Micro">'+svg('mic')+'</button>'+
            '<button id="ctl-cam" title="Caméra">'+svg('cam')+'</button>'+
            '<button id="ctl-hand" class="hand" title="Lever la main">'+svg('hand')+'</button>'+
            '<button id="ctl-chat" title="Chat">'+svg('chat')+'<span class="bdg" id="chat-bdg" style="display:none">0</span></button>'+
            '<button id="ctl-part" title="Participants">'+svg('users')+'</button>'+
            '<button id="ctl-notes" title="Notes">'+svg('notes')+'</button>'+
            '<button class="live-leave" id="ctl-leave">'+svg('exit')+'Quitter</button>'+
          '</div>'+
        '</div>'+
        '<div class="live-side" id="live-side" style="display:none"></div>'+
      '</div>';

    document.getElementById('ctl-leave').addEventListener('click', function(){ location.href = session.replayHref; });
    document.getElementById('ctl-mic').addEventListener('click', function(){
      micOn = !micOn; this.classList.toggle('off', !micOn); this.innerHTML = svg(micOn?'mic':'micOff');
      var tag = document.getElementById('you-tag'); tag.classList.toggle('muted', !micOn); tag.innerHTML = svg(micOn?'mic':'micOff')+'Daniel Learner Test (vous)';
      renderParticipantsIfOpen();
    });
    document.getElementById('ctl-cam').addEventListener('click', function(){
      camOn = !camOn; this.classList.toggle('off', !camOn); this.innerHTML = svg(camOn?'cam':'camOff');
      toast(camOn?'Caméra activée':'Caméra désactivée');
    });
    document.getElementById('ctl-hand').addEventListener('click', function(){
      handRaised = !handRaised; this.classList.toggle('active', handRaised);
      toast(handRaised?'Main levée — le formateur a été notifié':'Main baissée');
    });
    document.getElementById('ctl-chat').addEventListener('click', function(){ togglePanel('chat'); });
    document.getElementById('ctl-part').addEventListener('click', function(){ togglePanel('participants'); });
    document.getElementById('ctl-notes').addEventListener('click', function(){ togglePanel('notes'); });

    elapsed = 0;
    clearInterval(elapsedTimer);
    elapsedTimer = setInterval(function(){
      elapsed++;
      var m = Math.floor(elapsed/60), s = elapsed%60;
      var el = document.getElementById('lc-elapsed'); if(el) el.textContent = (m<10?'0':'')+m+':'+(s<10?'0':'')+s;
    }, 1000);

    togglePanel('chat');
  }

  function panelHead(title){
    return '<div class="live-side-head"><span>'+title+'</span><button id="panel-close">'+svg('close')+'</button></div>';
  }

  function renderChatPanel(){
    var side = document.getElementById('live-side');
    side.innerHTML = panelHead('CHAT') + '<div class="live-chat-thread" id="lc-thread"></div>'
      + '<div class="live-chat-compose"><input id="lc-input" type="text" placeholder="Écrire un message…"><button id="lc-send">'+svg('send')+'</button></div>';
    paintThread();
    document.getElementById('lc-send').addEventListener('click', sendMsg);
    document.getElementById('lc-input').addEventListener('keydown', function(e){ if(e.key==='Enter') sendMsg(); });
  }
  function paintThread(){
    var t = document.getElementById('lc-thread'); if(!t) return;
    t.innerHTML = chatMsgs.length ? chatMsgs.map(function(m){
      return '<div class="lbubble '+(m.who==='me'?'me':'them')+'">'+(m.who==='me'?'':'<b>'+session.formateur+'</b>')+m.text+'</div>';
    }).join('') : '<div class="live-chat-empty">Aucun message pour l\u2019instant. Lancez la discussion !</div>';
    t.scrollTop = t.scrollHeight;
    var bdg = document.getElementById('chat-bdg');
    if(bdg){ bdg.style.display = 'none'; }
  }
  function sendMsg(){
    var input = document.getElementById('lc-input'); var text = input.value.trim(); if(!text) return;
    chatMsgs.push({who:'me', text:text}); input.value=''; paintThread();
    setTimeout(function(){ chatMsgs.push({who:'them', text:'Merci pour votre message, on y revient dans un instant !'}); if(activePanel==='chat') paintThread(); else bumpChatBadge(); }, 1400);
  }
  function bumpChatBadge(){
    var bdg = document.getElementById('chat-bdg'); if(!bdg) return;
    bdg.textContent = (parseInt(bdg.textContent||'0',10)+1); bdg.style.display='grid';
  }

  function renderParticipantsPanel(){
    var side = document.getElementById('live-side');
    side.innerHTML = panelHead('PARTICIPANTS (2)') + '<div class="live-plist">'
      + '<div class="live-p"><span class="ava sm">DL</span><b>Daniel Learner Test (vous)</b><span class="icons">'+svg(micOn?'mic':'micOff')+svg(camOn?'cam':'camOff')+'</span></div>'
      + '<div class="live-p"><span class="ava sm">'+session.initials+'</span><b>'+session.formateur+'<span class="tag">Formateur</span></b><span class="icons">'+svg('mic')+'</span></div>'
      + '</div>';
  }
  function renderParticipantsIfOpen(){ if(activePanel==='participants') renderParticipantsPanel(); }

  function renderNotesPanel(){
    var side = document.getElementById('live-side');
    side.innerHTML = panelHead('MES NOTES') + '<div class="live-notes"><p>Notes personnelles, visibles par vous seul — utile pour retrouver un point précis dans le replay après le live.</p><textarea id="lc-notes" placeholder="Prenez vos notes ici pendant le live…"></textarea><small id="lc-notes-saved">Enregistré automatiquement · retrouvables sur la page du replay</small></div>';
    var ta = document.getElementById('lc-notes');
    ta.value = localStorage.getItem(notesKey) || '';
    ta.addEventListener('input', function(){ localStorage.setItem(notesKey, ta.value); });
  }

  function togglePanel(name){
    var side = document.getElementById('live-side');
    ['ctl-chat','ctl-part','ctl-notes'].forEach(function(id){ var b=document.getElementById(id); if(b) b.classList.remove('on-panel'); });
    if(activePanel===name){ activePanel=null; side.style.display='none'; return; }
    activePanel = name; side.style.display='flex';
    var btnId = name==='chat'?'ctl-chat':name==='participants'?'ctl-part':'ctl-notes';
    var btn = document.getElementById(btnId); if(btn) btn.classList.add('on-panel');
    if(name==='chat') renderChatPanel();
    else if(name==='participants') renderParticipantsPanel();
    else renderNotesPanel();
    shell.querySelector('.live-body').addEventListener('click', function(e){
      if(e.target.closest('#panel-close')){ activePanel=null; side.style.display='none'; btn && btn.classList.remove('on-panel'); }
    }, {once:true});
  }

  renderPending();
})();
