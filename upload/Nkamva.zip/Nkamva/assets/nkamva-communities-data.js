/* NkamVa — jeu de données mock des COMMUNAUTÉS (une par formateur, cf. modèle produit) */
window.NKCOMM = (function(){
  const A = NKAMVA.authors;
  const communities = [
    {slug:'ingenierie-logicielle-afrique',name:'Ingénierie logicielle Afrique',author:A.as,cat:'dev',price:5000,members:412,messages:34,lives:2,
      desc:"Un espace pour les développeurs qui construisent des systèmes sérieux : architecture, revue de code entre pairs, et sessions live sur des cas réels de production."},
    {slug:'qa-tests-logiciels',name:'QA & Tests logiciels',author:A.dt,cat:'dev',price:3000,members:187,messages:15,lives:1,
      desc:"La communauté des testeurs et QA d'Afrique francophone. Checklists partagées, retours d'expérience terrain, et entraide sur vos plans de test."},
    {slug:'createurs-video-montage',name:'Créateurs vidéo & montage',author:A.yo,cat:'dsg',price:4000,members:566,messages:41,lives:3,
      desc:"Monteurs et créateurs vidéo : partagez vos rushs, obtenez des retours sur vos montages, et suivez des lives de montage en direct chaque semaine."},
    {slug:'entrepreneurs-pme-ohada',name:'Entrepreneurs & PME OHADA',author:A.mt,cat:'biz',price:6000,members:298,messages:22,lives:2,
      desc:"Créateurs et dirigeants de PME dans l'espace OHADA : questions juridiques, conformité, et modèles partagés entre membres."},
    {slug:'freelances-independants',name:'Freelances & indépendants',author:A.km,cat:'biz',price:3500,members:341,messages:27,lives:1,
      desc:"Pilotez votre activité freelance : missions, facturation, organisation Notion — une communauté d'indépendants qui s'entraident."},
    {slug:'growth-marketing-local',name:'Growth & marketing local',author:A.fn,cat:'mkt',price:4500,members:229,messages:19,lives:2,
      desc:"SEO local, publicité, WhatsApp Business : des stratégies marketing pensées pour le commerce africain, testées en direct."},
    {slug:'design-produit-afrique',name:'Design produit Afrique',author:A.jk,cat:'dsg',price:5500,members:503,messages:38,lives:3,
      desc:"Product designers et UI/UX : critiques de fichiers Figma, discussions design system, et lives de conception en direct."},
  ];
  const salons = [
    {key:'forum',label:'Forum',desc:"Échanges et questions de la communauté",icon:'<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>'},
    {key:'res',label:'Ressources',desc:"Documents et supports partagés",icon:'<circle cx="12" cy="12" r="9"/><path d="M12 8v4l3 2"/>'},
    {key:'live',label:'Lives & Replays',desc:"Sessions en direct et rediffusions",icon:'<circle cx="12" cy="12" r="9"/><path d="M10 9l5 3-5 3z" fill="currentColor" stroke="none"/>'},
  ];
  function bySlug(s){return communities.find(c=>c.slug===s);}
  communities.forEach(c=>{ c.category = NKAMVA.categories.find(x=>x.id===c.cat); });
  return {communities,salons,bySlug};
})();
