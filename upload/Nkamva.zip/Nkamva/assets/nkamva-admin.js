(function(){
  function boot(){
    if (window.__nkAdminBooted) return;
    window.__nkAdminBooted = true;
    function closeSide(){ var s=document.querySelector('.adm-side'); var b=document.querySelector('.adm-backdrop'); s && s.classList.remove('open'); b && b.classList.remove('on'); }
    document.body.addEventListener('click', function(e){
      if (e.target.closest('.adm-mtop button')){ var s=document.querySelector('.adm-side'); var b=document.querySelector('.adm-backdrop'); s && s.classList.toggle('open'); b && b.classList.toggle('on'); return; }
      if (e.target.closest('.adm-backdrop')){ closeSide(); }
    });

    // ===== moderation rules page =====
    function add_mod_history(label, color){
      var hist = document.getElementById('modHistory');
      if (!hist) return;
      var row = document.createElement('div');
      row.style.cssText = 'display:flex;gap:12px;align-items:flex-start;padding:13px 0;border-bottom:1px solid var(--line2)';
      row.innerHTML = '<div style="width:8px;height:8px;border-radius:50%;background:var(--' + (color || 'green') + ');margin-top:6px;flex:none"></div><div style="flex:1;min-width:0"><b style="display:block;font-size:13.5px;font-weight:700">' + label + '</b><small style="color:var(--ink3);font-size:12px">Nadia Fotso · aujourd\'hui</small></div>';
      hist.insertBefore(row, hist.firstChild);
    }
    document.body.addEventListener('click', function(e){
      var tg = e.target.closest('.tgl[data-rule-name]');
      if (tg){
        var on = tg.getAttribute('aria-pressed') === 'true';
        tg.setAttribute('aria-pressed', on ? 'false' : 'true');
        add_mod_history(tg.getAttribute('data-rule-name') + ' → ' + (on ? 'désactivé' : 'activé'), on ? 'ink3' : 'green');
        return;
      }
      var rm = e.target.closest('.kw-remove');
      if (rm){
        var kw = rm.getAttribute('data-kw');
        var chip = rm.closest('.kw-chip');
        if (chip) chip.remove();
        add_mod_history('Suppression mot-clé « ' + kw + ' »', 'red');
        return;
      }
      var add = e.target.closest('#addKeywordBtn');
      if (add){
        var kw2 = window.prompt('Nouveau mot-clé à surveiller :');
        if (kw2 && kw2.trim()){
          kw2 = kw2.trim();
          var list = document.getElementById('kwList');
          if (list){
            var span = document.createElement('span');
            span.className = 'rchip kw-chip';
            span.style.cssText = 'background:var(--paper);border:1px solid var(--line);border-radius:999px;padding:6px 8px 6px 14px;display:inline-flex;align-items:center;gap:8px';
            span.textContent = kw2;
            var btn = document.createElement('button');
            btn.type = 'button'; btn.className = 'kw-remove'; btn.setAttribute('data-kw', kw2);
            btn.setAttribute('aria-label', 'Retirer');
            btn.style.cssText = 'border:none;background:var(--line2);color:var(--ink2);cursor:pointer;width:18px;height:18px;border-radius:50%;font-weight:700;line-height:1;display:grid;place-items:center;padding:0';
            btn.textContent = '×';
            span.appendChild(btn);
            list.appendChild(span);
          }
          add_mod_history('Ajout mot-clé « ' + kw2 + ' »', 'blue');
        }
        return;
      }
    });

    // ===== manage team member =====
    var roleMeta = {
      finances: {label: 'Finances', color: 'var(--green)', cls: ''},
      moderation: {label: 'Modération', color: 'var(--blue)', cls: 'formateur'},
      superadmin: {label: 'Super-admin', color: 'var(--gold)', cls: 'admin'}
    };
    document.body.addEventListener('click', function(e){
      var mb = e.target.closest('[data-manage-member]');
      if (mb){
        var modal = document.getElementById('manage-member-modal');
        if (!modal) return;
        modal.setAttribute('data-key', mb.getAttribute('data-manage-member'));
        var nameEl = document.getElementById('manage-name'); if (nameEl) nameEl.textContent = 'Gérer ' + mb.getAttribute('data-member-name');
        var emailEl = document.getElementById('manage-email'); if (emailEl) emailEl.textContent = mb.getAttribute('data-member-email');
        var role = mb.getAttribute('data-member-role');
        modal.querySelectorAll('#manageRoleTabs button').forEach(function(b){ b.classList.toggle('on', b.getAttribute('data-filter') === role); });
        modal.classList.add('open');
        return;
      }
      var ci = e.target.closest('[data-cancel-invite]');
      if (ci){
        var row = ci.closest('[data-member-key]');
        if (row) row.remove();
        return;
      }
      var rtab = e.target.closest('#manageRoleTabs button');
      if (rtab){
        rtab.parentElement.querySelectorAll('button').forEach(function(b){ b.classList.remove('on'); });
        rtab.classList.add('on');
        return;
      }
      var save = e.target.closest('#manage-save');
      if (save){
        var modal2 = document.getElementById('manage-member-modal');
        var key = modal2.getAttribute('data-key');
        var activeBtn = modal2.querySelector('#manageRoleTabs button.on');
        var roleKey = activeBtn ? activeBtn.getAttribute('data-filter') : 'finances';
        var meta = roleMeta[roleKey];
        var row2 = document.querySelector('[data-member-key="' + key + '"]');
        if (row2){
          var pill = row2.querySelector('.member-role');
          if (pill){ pill.className = 'rchip member-role' + (meta.cls ? ' ' + meta.cls : ''); pill.style.color = meta.cls ? '' : meta.color; pill.textContent = meta.label; }
          var btn2 = row2.querySelector('[data-manage-member]');
          if (btn2) btn2.setAttribute('data-member-role', roleKey);
        }
        modal2.classList.remove('open');
        return;
      }
      var remove = e.target.closest('#manage-remove');
      if (remove){
        var modal3 = document.getElementById('manage-member-modal');
        var key3 = modal3.getAttribute('data-key');
        var row3 = document.querySelector('[data-member-key="' + key3 + '"]');
        if (row3) row3.remove();
        modal3.classList.remove('open');
        return;
      }
    });

    // ===== communication broadcasts =====
    function comm_segment_label(){
      var b = document.querySelector('#commSegment button.on');
      return b ? b.textContent : 'Tous les comptes';
    }
    document.body.addEventListener('click', function(e){
      var send = e.target.closest('#commSendNow');
      if (send){
        var subj = document.getElementById('commSubject');
        var list = document.getElementById('commRecent');
        if (list && subj){
          var empty = list.querySelector('.adm-empty'); if (empty) empty.remove();
          var row = document.createElement('div');
          row.style.cssText = 'padding:12px 0;border-bottom:1px solid var(--line2)';
          row.innerHTML = '<div style="display:flex;justify-content:space-between;gap:10px;margin-bottom:3px"><b style="font-size:14px">' + subj.value + '</b><span style="font-size:12px;color:var(--ink3);white-space:nowrap">' + comm_segment_label() + ' · à l\'instant</span></div><small style="color:var(--ink3);font-size:12.5px">Envoyé</small>';
          list.insertBefore(row, list.firstChild);
        }
        return;
      }
      var sched = e.target.closest('#commSchedule');
      if (sched){
        var subj2 = document.getElementById('commSubject');
        var list2 = document.getElementById('commScheduled');
        var when = window.prompt('Planifier pour quelle date/heure ?', 'Demain 09:00');
        if (when && subj2 && list2){
          var empty2 = list2.querySelector('.adm-empty'); if (empty2) empty2.remove();
          var row2 = document.createElement('div');
          row2.style.cssText = 'padding:12px 0;border-bottom:1px solid var(--line2)';
          row2.innerHTML = '<div style="display:flex;justify-content:space-between;gap:10px"><b style="font-size:14px">' + subj2.value + '</b><span class="stpill warn" style="white-space:nowrap"><i></i>' + when + '</span></div><small style="color:var(--ink3);font-size:12.5px">' + comm_segment_label() + '</small>';
          list2.insertBefore(row2, list2.firstChild);
        }
        return;
      }
    });

    document.body.addEventListener('click', function(e){
      if (e.target.closest('.is-disabled')){ e.preventDefault(); e.stopImmediatePropagation(); return; }
    }, true);

    // ===== 2FA toggle =====
    document.body.addEventListener('click', function(e){
      var tw = e.target.closest('[data-2fa-toggle]');
      if (tw){
        var on = tw.getAttribute('aria-pressed') === 'true';
        tw.setAttribute('aria-pressed', on ? 'false' : 'true');
        var panel = document.getElementById('twofaPanel');
        if (panel) panel.style.display = on ? 'none' : '';
        return;
      }
      var confirm2fa = e.target.closest('#twofaConfirm');
      if (confirm2fa){
        var panel2 = document.getElementById('twofaPanel');
        if (panel2) panel2.innerHTML = '<div style="display:flex;align-items:center;gap:10px;color:var(--green-d);font-weight:700;font-size:13.8px"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:18px;height:18px"><circle cx="12" cy="12" r="9"></circle><path d="m8.5 12.5 2.5 2.5 5-5"></path></svg>Double authentification activée</div>';
        return;
      }
    });

    document.body.addEventListener('click', function(e){
      var card = e.target.closest('.adm-role-card');
      if (!card) return;
      var siblings = card.parentElement.querySelectorAll('.adm-role-card');
      siblings.forEach(function(s){ s.classList.remove('on'); });
      card.classList.add('on');
    });

    function apply_tabscope(scope){
      var tabs = scope.querySelector('.adm-tabs');
      var activeBtn = tabs ? tabs.querySelector('button.on') : null;
      var filter = activeBtn ? activeBtn.getAttribute('data-filter') : null;
      var search = scope.querySelector('[data-adm-search]') || document.querySelector('[data-adm-search]');
      var q = search ? search.value.trim().toLowerCase() : '';
      scope.querySelectorAll('[data-role]').forEach(function(row){
        var roleOk = (!filter || filter === 'all' || row.getAttribute('data-role') === filter);
        var textOk = !q || row.textContent.toLowerCase().indexOf(q) !== -1;
        row.style.display = (roleOk && textOk) ? '' : 'none';
      });
    }
    document.querySelectorAll('[data-tabscope]').forEach(apply_tabscope);

    document.body.addEventListener('click', function(e){
      var b = e.target.closest('.adm-tabs button');
      if (!b) return;
      var tabs = b.closest('.adm-tabs');
      var scope = b.closest('[data-tabscope]');
      tabs.querySelectorAll('button').forEach(function(x){ x.classList.remove('on'); });
      b.classList.add('on');
      if (scope) apply_tabscope(scope);
    });
    document.body.addEventListener('input', function(e){
      var s = e.target.closest('[data-adm-search]');
      if (!s) return;
      var scope = s.closest('[data-tabscope]');
      if (scope) apply_tabscope(scope);
      else document.querySelectorAll('[data-tabscope]').forEach(apply_tabscope);
    });

    // country filter dropdown
    var countryNames = {CM:'Cameroun',CI:"Côte d'Ivoire",SN:'Sénégal',GA:'Gabon',BJ:'Bénin',BF:'Burkina Faso',ML:'Mali',TG:'Togo',CD:'RDC',KE:'Kenya'};
    document.querySelectorAll('[data-country-btn]').forEach(function(btn){
      var wrap = btn.closest('.adm-popwrap');
      var dd = wrap.querySelector('[data-country-dd]');
      var label = btn.querySelector('[data-country-label]');
      var clearIc = btn.querySelector('[data-country-clear]');
      var search = wrap.querySelector('[data-country-search]');
      var scope = btn.closest('[data-tabscope]') || document;
      function clearFilter(){
        label.textContent = 'Pays';
        btn.classList.remove('on');
        btn.removeAttribute('data-country-active');
        if (clearIc) clearIc.style.display = 'none';
        scope.querySelectorAll('[data-country]').forEach(function(row){ row.style.display = ''; });
      }
      btn.addEventListener('click', function(e){
        if (clearIc && (e.target === clearIc || clearIc.contains(e.target))){ e.stopPropagation(); clearFilter(); return; }
        e.stopPropagation(); dd.classList.toggle('open'); if (dd.classList.contains('open') && search) search.focus();
      });
      if (search) search.addEventListener('input', function(){
        var q = search.value.trim().toLowerCase();
        wrap.querySelectorAll('[data-country-opt]').forEach(function(o){ o.hidden = q && o.textContent.toLowerCase().indexOf(q) === -1; });
      });
      wrap.querySelectorAll('[data-country-opt]').forEach(function(o){
        o.addEventListener('click', function(){
          var code = o.getAttribute('data-country-opt');
          label.textContent = countryNames[code] || code;
          btn.classList.add('on');
          btn.setAttribute('data-country-active', code);
          if (clearIc) clearIc.style.display = 'inline-flex';
          dd.classList.remove('open');
          scope.querySelectorAll('[data-country]').forEach(function(row){
            row.style.display = row.getAttribute('data-country') === code ? '' : 'none';
          });
        });
      });
    });
    document.addEventListener('click', function(e){
      document.querySelectorAll('.adm-popdd.open').forEach(function(dd){
        if (!dd.closest('.adm-popwrap').contains(e.target)) dd.classList.remove('open');
      });
    });

    // generic modal open/close (delegated so dynamically-created buttons work too)
    document.body.addEventListener('click', function(e){
      var b = e.target.closest('[data-modal-open]');
      if (!b) return;
      e.preventDefault();
      var m = document.getElementById(b.getAttribute('data-modal-open'));
      if (!m) return;
      var key = b.getAttribute('data-dossier-key');
      m.dataset.key = key || '';
      if (key && window.ADM_DOSSIERS && window.ADM_DOSSIERS[key]) fillDossier(m, window.ADM_DOSSIERS[key], key);
      m.classList.add('open');
    });
    function fillDossier(m, d, key){
      var ava = m.querySelector('#dm-ava'); if (ava){ ava.textContent = d.initials; ava.style.background = d.bg; }
      var nm = m.querySelector('#dm-name'); if (nm) nm.textContent = d.name;
      var chips = m.querySelector('#dm-chips'); if (chips){ chips.innerHTML = ''; (d.chips||[]).forEach(function(c){ var s=document.createElement('span'); s.className='rchip'; s.textContent=c; chips.appendChild(s); }); }
      var email = m.querySelector('#dm-email'); if (email) email.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4Z"></path><path d="m4 6 8 7 8-7"></path></svg>' + d.email;
      var desc = m.querySelector('#dm-desc'); if (desc) desc.textContent = d.desc;
      var docs = m.querySelector('#dm-docs'); if (docs){
        docs.innerHTML = '';
        (d.docs||[]).forEach(function(doc){
          var row = document.createElement('div');
          row.className = 'dm-doc-row';
          var okIcon = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 13 4 4L19 7"></path></svg>';
          var badIcon = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--red)" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6l12 12M18 6 6 18"></path></svg>';
          row.innerHTML = '<span class="lbl"><span class="ic" style="background:' + (doc.ok ? 'var(--green-t)' : 'var(--red-t)') + '">' + (doc.ok ? okIcon : badIcon) + '</span>' + doc.label + '</span>' +
            '<span style="display:flex;align-items:center;gap:8px"><button type="button" class="btn btn-o btn-sm" data-view-doc="' + doc.label + '">Voir</button><span class="stpill ' + (doc.ok ? 'ok' : 'bad') + '"><i></i>' + (doc.ok ? 'Vérifié' : 'Manquant') + '</span></span>';
          docs.appendChild(row);
        });
      }
      var meta = m.querySelector('#dm-meta'); if (meta) meta.textContent = d.meta;
      var actions = m.querySelector('#dm-actions');
      if (actions){
        if (d.status === 'attente') actions.innerHTML = '<button class="btn btn-danger btn-sm" data-reject-key="' + key + '">Rejeter</button><button class="btn btn-p btn-sm" data-approve-key="' + key + '">Approuver</button>';
        else actions.innerHTML = '<button class="btn btn-o btn-sm" data-modal-close>Fermer</button>';
      }
    }

    // ---- validation formateurs : approuver / rejeter (déplace la fiche entre les onglets) ----
    if (window.ADM_DOSSIERS){
      var rejectModal = document.getElementById('reject-modal');

      function bump(id, delta){
        var el = document.getElementById(id);
        if (!el) return;
        var n = Math.max(0, (parseInt(el.textContent, 10) || 0) + delta);
        el.textContent = n;
        if (id === 'nav-badge-validation') el.style.display = n ? '' : 'none';
      }
      function findCard(key){ return document.querySelector('.adm-card[data-dossier-key="' + key + '"]'); }
      function resyncVisibility(card){
        var activeBtn = document.querySelector('[data-tabscope] .adm-tabs button.on');
        var filter = activeBtn ? activeBtn.getAttribute('data-filter') : 'attente';
        card.style.display = (filter === card.getAttribute('data-role')) ? '' : 'none';
      }

      function applyApprove(key){
        var d = window.ADM_DOSSIERS[key], card = findCard(key);
        if (!d || !card || d.status !== 'attente') return;
        d.status = 'approuve';
        card.setAttribute('data-role', 'approuve');
        var docrow = card.querySelector('.adm-docrow'); if (docrow) docrow.remove();
        var foot = card.children[card.children.length - 1];
        foot.innerHTML = '<span class="stpill ok"><i></i>Approuvée aujourd\'hui · par Nadia Fotso</span><a class="btn btn-o btn-sm" href="Admin Utilisateur Profil.dc.html?role=formateur">Voir le profil</a>';
        bump('stat-attente', -1); bump('stat-approuve', 1); bump('nav-badge-validation', -1);
        resyncVisibility(card);
        var dm = document.getElementById('dossier-modal'); if (dm) dm.classList.remove('open');
      }

      function applyReject(key, badDocs, reason){
        var d = window.ADM_DOSSIERS[key], card = findCard(key);
        if (!d || !card || d.status !== 'attente') return;
        d.status = 'rejete';
        d.reason = reason;
        (d.docs || []).forEach(function(doc){ if (badDocs.indexOf(doc.label) !== -1) doc.ok = false; });
        card.setAttribute('data-role', 'rejete');
        var docrow = card.querySelector('.adm-docrow'); if (docrow) docrow.remove();
        var desc = card.querySelector('p'); if (desc) desc.textContent = 'Motif du refus (' + badDocs.join(', ') + ') : ' + reason;
        var foot = card.children[card.children.length - 1];
        foot.innerHTML = '<span class="stpill bad"><i></i>Rejetée aujourd\'hui · par Nadia Fotso</span><button class="btn btn-o btn-sm" data-modal-open="dossier-modal" data-dossier-key="' + key + '">Voir le dossier</button>';
        bump('stat-attente', -1); bump('stat-rejete', 1); bump('nav-badge-validation', -1);
        resyncVisibility(card);
        if (rejectModal) rejectModal.classList.remove('open');
        var dm = document.getElementById('dossier-modal'); if (dm) dm.classList.remove('open');
      }

      function openRejectModal(key){
        var d = window.ADM_DOSSIERS[key];
        if (!d || !rejectModal) return;
        rejectModal.dataset.key = key;
        var wrap = rejectModal.querySelector('#rj-docs');
        if (wrap){
          wrap.innerHTML = '';
          (d.docs || []).forEach(function(doc, i){
            var row = document.createElement('label');
            row.style.cssText = 'display:flex;align-items:center;gap:10px;font-size:14px;font-weight:600;color:var(--ink);cursor:pointer';
            row.innerHTML = '<input type="checkbox" value="' + doc.label + '" ' + (!doc.ok ? 'checked' : '') + ' style="width:17px;height:17px;accent-color:var(--red);flex:none">' + doc.label;
            wrap.appendChild(row);
          });
        }
        var reasonEl = rejectModal.querySelector('#rj-reason'); if (reasonEl) reasonEl.value = '';
        rejectModal.classList.add('open');
      }

      var rjConfirm = document.getElementById('rj-confirm');
      if (rjConfirm) rjConfirm.addEventListener('click', function(){
        var key = rejectModal.dataset.key;
        var checked = Array.prototype.slice.call(rejectModal.querySelectorAll('#rj-docs input:checked')).map(function(i){ return i.value; });
        var reasonEl = rejectModal.querySelector('#rj-reason');
        var reason = reasonEl ? reasonEl.value.trim() : '';
        if (!checked.length){ alert('Sélectionnez au moins un document à corriger.'); return; }
        if (!reason){ alert('Merci de préciser un motif pour le formateur.'); return; }
        applyReject(key, checked, reason);
      });

      document.body.addEventListener('click', function(e){
        var ab = e.target.closest('[data-approve-key]');
        if (ab){ applyApprove(ab.getAttribute('data-approve-key')); return; }
        var rb = e.target.closest('[data-reject-key]');
        if (rb){ openRejectModal(rb.getAttribute('data-reject-key')); return; }
        var vb = e.target.closest('[data-view-doc]');
        if (vb){
          var dv = document.getElementById('doc-viewer');
          if (dv){
            var t = dv.querySelector('#dv-title'); if (t) t.textContent = vb.getAttribute('data-view-doc');
            dv.classList.add('open');
          }
        }
      });
    }
    document.body.addEventListener('click', function(e){
      var b = e.target.closest('[data-modal-close]');
      if (!b) return;
      e.preventDefault();
      var m = b.closest('.adm-modal');
      if (m) m.classList.remove('open');
    });

    // generic view-switch tabs: buttons[data-view] toggle sibling panels[data-panel]
    document.body.addEventListener('click', function(e){
      var btn = e.target.closest('[data-viewtabs] button[data-view]');
      if (!btn) return;
      var group = btn.closest('[data-viewtabs]');
      group.querySelectorAll('button[data-view]').forEach(function(b){ b.classList.remove('on'); });
      btn.classList.add('on');
      var key = btn.getAttribute('data-view');
      document.querySelectorAll('[data-panel]').forEach(function(panel){
        panel.style.display = (panel.getAttribute('data-panel') === key) ? '' : 'none';
      });
    });
    // ===== disputes (remboursements & litiges) =====
    function resync_dispute(card){
      var scope = card.closest('[data-tabscope]');
      var active_btn = scope ? scope.querySelector('.adm-tabs button.on') : null;
      var filter = active_btn ? active_btn.getAttribute('data-filter') : 'ouvert';
      card.style.display = (filter === card.getAttribute('data-role')) ? '' : 'none';
    }
    function bump2(id, delta){
      var el = document.getElementById(id);
      if (!el) return;
      var n = parseInt(el.textContent.replace(/\D/g,''), 10) || 0;
      el.textContent = (n + delta);
    }
    function settle_dispute(key, ok){
      var card = document.querySelector('[data-dispute-key="' + key + '"]');
      if (!card) return;
      card.setAttribute('data-role', 'resolu');
      var pill = card.querySelector('.stpill');
      if (pill){ pill.className = 'stpill ' + (ok ? 'ok' : 'bad'); pill.innerHTML = '<i></i>' + (ok ? 'Remboursé' : 'Rejeté'); }
      var motif = card.querySelector('.disp-motif');
      if (motif){
        motif.style.borderLeftColor = ok ? 'var(--green)' : 'var(--red)';
        motif.style.background = ok ? 'var(--green-t)' : 'var(--red-t)';
        motif.style.fontStyle = 'normal';
        motif.textContent = ok ? "Résolu aujourd'hui par Nadia Fotso — remboursement intégral effectué." : "Rejeté aujourd'hui par Nadia Fotso — réclamation jugée non fondée.";
      }
      var actions = card.querySelector('.disp-actions');
      if (actions) actions.innerHTML = '<button class="btn btn-o btn-sm" data-modal-open="thread-' + key + '">Voir les échanges</button>';
      bump2('stat-open', -1); bump2('stat-resolved', 1);
      resync_dispute(card);
    }
    // ===== reports (signalements) =====
    function settle_report(key, outcome){
      var card = document.querySelector('[data-report-key="' + key + '"]');
      if (!card) return;
      var newRole = outcome === 'rejete' ? 'rejete' : 'resolu';
      card.setAttribute('data-role', newRole);
      var pill = card.querySelector('.stpill');
      if (pill){
        pill.className = 'stpill ' + (outcome === 'rejete' ? 'bad' : 'ok');
        pill.innerHTML = '<i></i>' + (outcome === 'rejete' ? 'Rejeté' : 'Résolu');
      }
      var motif = card.querySelector('.rep-motif');
      if (motif){
        var color = outcome === 'rejete' ? 'red' : 'green';
        motif.style.borderLeftColor = 'var(--' + color + ')';
        motif.style.background = 'var(--' + color + '-t)';
        motif.textContent = outcome === 'rejete'
          ? "Rejeté aujourd'hui par Nadia Fotso — signalement jugé non fondé."
          : "Traité aujourd'hui par Nadia Fotso — " + (outcome === 'suspendu' ? 'compte suspendu.' : 'contenu supprimé.');
      }
      var actions = card.querySelector('.rep-actions');
      if (actions) actions.innerHTML = '';
      bump2('stat-rep-open', -1);
      if (outcome === 'rejete') { var ph = document.getElementById('rep-empty-rejete'); if (ph) ph.remove(); } else { bump2('stat-rep-resolved', 1); }
      resync_dispute(card);
    }
    document.body.addEventListener('click', function(e){
      var rj = e.target.closest('[data-reject-report]');
      if (rj){ settle_report(rj.getAttribute('data-reject-report'), 'rejete'); return; }
      var rm = e.target.closest('[data-remove-content]');
      if (rm){ settle_report(rm.getAttribute('data-remove-content'), 'supprime'); return; }
      var su = e.target.closest('[data-suspend-account]');
      if (su){ settle_report(su.getAttribute('data-suspend-account'), 'suspendu'); return; }
    });

    document.body.addEventListener('click', function(e){
      var rf = e.target.closest('[data-refund-dispute]');
      if (rf){ settle_dispute(rf.getAttribute('data-refund-dispute'), true); return; }
      var rj = e.target.closest('[data-reject-dispute]');
      if (rj){ settle_dispute(rj.getAttribute('data-reject-dispute'), false); return; }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
