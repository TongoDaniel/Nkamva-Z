/* NkamVa — logique listing Communautés : onglets catégorie, recherche, tri */
(function(){
  const C = NKCOMM.communities;
  const grid = document.getElementById('cgrid');
  const search = document.getElementById('cq');
  const sortSel = document.getElementById('csort');
  const resN = document.getElementById('cresn');
  const tabsWrap = document.getElementById('ctabs');
  const state = {cat:'all', q:'', sort:'pop'};

  const tabs = [{id:'all',label:'Toutes'}].concat(NKAMVA.categories.map(c=>({id:c.id,label:c.label})));
  tabsWrap.innerHTML = tabs.map(t=>'<button data-cat="'+t.id+'" class="'+(t.id==='all'?'on':'')+'">'+t.label+'</button>').join('');

  function apply(){
    let list = C.filter(c=>{
      if(window.NK_SPACE==='learner' && (window.NK_JOINED_SLUGS||[]).indexOf(c.slug)!==-1) return false;
      if(state.cat!=='all' && c.cat!==state.cat) return false;
      if(state.q){const q=state.q.toLowerCase(); if(!(c.name.toLowerCase().includes(q)||c.author.name.toLowerCase().includes(q))) return false;}
      return true;
    });
    list.sort((a,b)=> state.sort==='price-a'?a.price-b.price : state.sort==='price-d'?b.price-a.price : b.members-a.members);
    render(list);
  }
  function render(list){
    resN.innerHTML = '<b>'+list.length+'</b> communauté'+(list.length>1?'s':'');
    if(!list.length){
      grid.className='';
      grid.innerHTML='<div class="empty" style="grid-column:1/-1"><div class="eic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg></div><h3>Aucune communauté trouvée</h3><p>Essayez une autre catégorie ou un autre terme de recherche.</p></div>';
      return;
    }
    grid.className='cgrid';
    grid.innerHTML = list.map((c,i)=>commCard(c,i)).join('');
  }

  tabsWrap.addEventListener('click',e=>{
    const b=e.target.closest('button[data-cat]'); if(!b) return;
    state.cat=b.dataset.cat;
    [...tabsWrap.children].forEach(x=>x.classList.toggle('on',x===b));
    apply();
  });
  let t; search.addEventListener('input',()=>{clearTimeout(t); t=setTimeout(()=>{state.q=search.value.trim(); apply();},220);});
  sortSel.addEventListener('change',()=>{state.sort=sortSel.value; apply();});

  apply();
})();
