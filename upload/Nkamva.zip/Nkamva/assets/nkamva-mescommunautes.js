/* NkamVa — Mes communautés (espace apprenant) : communautés déjà rejointes */
window.NK_JOINED_SLUGS = ['qa-tests-logiciels', 'ingenierie-logicielle-afrique'];
(function(){
  var wrap = document.getElementById('mycomm-list');
  if(!wrap) return;
  var extra = window.NK_PURCHASES ? NK_PURCHASES.extraJoined() : [];
  var allSlugs = window.NK_JOINED_SLUGS.concat(extra.filter(function(s){ return window.NK_JOINED_SLUGS.indexOf(s)===-1; }));
  var joined = allSlugs.map(function(s){ return NKCOMM.bySlug(s); }).filter(Boolean);
  document.getElementById('mycomm-n').textContent = joined.length;
  if(!joined.length){ wrap.closest('.mycomm-sec').style.display='none'; return; }
  document.getElementById('mycomm-list').innerHTML = joined.map(function(c){
    return '<div class="mr-card">'
      +'<div class="mr-thumb ava" style="background:var(--line2);color:var(--ink2);font:700 15px var(--body)">'+c.author.initials+'</div>'
      +'<div class="mr-tx"><h3><a href="Communaute apprenant.dc.html?c='+c.slug+'">'+c.name+'</a></h3>'
      +'<p>Animée par '+c.author.name+' · '+c.members.toLocaleString('fr-FR')+' membres</p></div>'
      +'<div class="mr-actions"><a class="btn btn-p btn-sm" href="Communaute apprenant.dc.html?c='+c.slug+'">Ouvrir</a></div></div>';
  }).join('');
})();
