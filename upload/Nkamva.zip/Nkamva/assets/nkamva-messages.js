/* NkamVa — Messagerie apprenant : une conversation par formateur des communautés rejointes */
(function(){
  var contacts = [
    {id:'dt', name:'Daniel Tongo', role:'Lead QA & testeur', email:'daniel.tongo@exemple.cm', initials:'DT', grad:'#3b82f6,#2563eb', community:'QA & Tests logiciels',
      seed:[{who:'them', text:"Bonjour Daniel, merci pour votre présence au live technique ! Le replay est en ligne si vous voulez revoir un passage.", when:'17 juil.'}]},
    {id:'as', name:'Aminata Sow', role:'Architecte logicielle', email:'aminata.sow@exemple.sn', initials:'AS', grad:'#7c3aed,#5b21b6', community:'Ingénierie logicielle Afrique',
      seed:[{who:'them', text:"Salut ! Le replay sur l'architecture des systèmes de paiement est disponible dans la communauté, n'hésitez pas si vous avez des questions.", when:'14 juil.'}]}
  ];

  function key(id){ return 'nk_dm_'+id; }
  function loadMsgs(c){
    var m; try{ m = JSON.parse(localStorage.getItem(key(c.id))); }catch(e){ m = null; }
    if(!Array.isArray(m)) m = c.seed.slice();
    return m;
  }
  contacts.forEach(function(c){ c.msgs = loadMsgs(c); });

  var active = contacts[0].id;
  function byId(id){ return contacts.find(function(c){ return c.id===id; }); }
  function lastText(c){ var m=c.msgs; return m.length ? m[m.length-1].text : ''; }

  function renderList(){
    document.getElementById('msg-list').innerHTML = contacts.map(function(c){
      return '<div class="msg-item'+(c.id===active?' on':'')+'" data-id="'+c.id+'"><span class="ava sm" style="background:linear-gradient(135deg,'+c.grad+')">'+c.initials+'</span>'
        +'<div class="mtx"><b>'+c.name+'</b><p>'+lastText(c)+'</p></div><time>'+c.msgs[c.msgs.length-1].when+'</time></div>';
    }).join('');
    document.querySelectorAll('.msg-item').forEach(function(el){
      el.addEventListener('click', function(){ active = el.dataset.id; renderAll(); });
    });
  }
  function renderHead(){
    var c = byId(active);
    document.getElementById('msg-head').innerHTML =
      '<span class="ava sm" style="background:linear-gradient(135deg,'+c.grad+')">'+c.initials+'</span>'
      +'<div><b>'+c.name+'</b><small>'+c.role+' · '+c.community+'</small></div>';
    document.getElementById('msg-input').placeholder = 'Écrire à '+c.name.split(' ')[0]+'…';
  }
  function renderThread(){
    var c = byId(active);
    var t = document.getElementById('msg-thread');
    t.innerHTML = c.msgs.map(function(m){
      return '<div class="bubble '+(m.who==='me'?'me':'them')+'">'+m.text+'<time>'+m.when+'</time></div>';
    }).join('');
    t.scrollTop = t.scrollHeight;
  }
  function renderAll(){ renderList(); renderHead(); renderThread(); }
  renderAll();

  function send(){
    var input = document.getElementById('msg-input');
    var text = input.value.trim(); if(!text) return;
    var c = byId(active);
    c.msgs.push({who:'me', text:text, when:"à l'instant"});
    localStorage.setItem(key(c.id), JSON.stringify(c.msgs));
    input.value = '';
    renderAll();
  }
  document.getElementById('msg-send').addEventListener('click', send);
  document.getElementById('msg-input').addEventListener('keydown', function(e){ if(e.key==='Enter') send(); });
})();
