/* NkamVa — fiche ressource : rend le détail depuis ?r=slug */
(function(){
  const slug = new URLSearchParams(location.search).get('r');
  const r = NKAMVA.bySlug(slug) || NKAMVA.resources[0];
  document.title = r.title + ' — NkamVa';

  const CK='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
  const P=NKAMVA.fmtPrice;

  // ---- colonne principale ----
  const learn = r.learn.map(l=>'<li><span class="ck">'+CK+'</span>'+l+'</li>').join('');
  const curr = r.curriculum.map((m,i)=>{
    const lessons=[];
    for(let j=0;j<m.lessons;j++){
      const isVid = r.fmt==='video';
      const ic = isVid?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M10 9l5 3-5 3z" fill="currentColor" stroke="none"/></svg>'
        :'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5"/></svg>';
      const d = isVid ? (6+((i*3+j)%9))+' min' : (2+((i+j)%4))+' pages';
      lessons.push('<div class="lesson">'+ic+'Leçon '+(j+1)+' — '+m.title.split(',')[0].toLowerCase()+'<span class="dur">'+d+'</span></div>');
    }
    return '<div class="qa'+(i===0?' open':'')+'"><button class="q" type="button">'+m.title
      +'<span class="modmeta"><span>'+m.lessons+' leçons</span><span class="x"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></span></button>'
      +'<div class="a"><div class="ain">'+lessons.join('')+'</div></div></div>';
  }).join('');


  const a=r.author;
  const catBase = window.NK_SPACE==='learner' ? 'Catalogue apprenant.dc.html' : 'Catalogue.dc.html';
  document.getElementById('ficheroot').innerHTML =
    '<nav class="crumb"><a href="'+catBase+'">Ressources</a><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>'
      +'<a href="'+catBase+'?cat='+r.cat+'">'+r.category.label+'</a><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg><span>'+r.title+'</span></nav>'
    +'<div class="dhead"><span class="chip '+r.category.chip+'">'+r.category.label+'</span><h1>'+r.title+'</h1>'
      +'<div class="dmeta"><span class="it"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>'+r.students.toLocaleString('fr-FR')+' apprenants</span>'
      +'<span class="sep"></span><span class="it"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>'+r.lang+'</span>'
      +'<span class="sep"></span><button type="button" class="it" id="reportBtn" style="border:none;background:none;cursor:pointer;color:var(--ink3);text-decoration:underline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M5 21V4"/><path d="M5 5h12l-2.5 4L17 13H5"/></svg>Signaler ce contenu</button></div></div>'
    +'<div class="dhero"><div class="cover '+r.category.cover+'">'+NK_glyph(r.format)
      +(r.fmt==='video'?'<button class="playbtn" aria-label="Aperçu vidéo"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button><span class="prevtag">Aperçu gratuit · 2 min</span>':'<span class="prevtag">'+r.format.label+' · '+r.meta+'</span>')+'</div></div>'
    +'<section class="dsec"><h2>À propos de cette ressource</h2><p>'+r.blurb+'</p><p>Vous l\u2019achetez une seule fois, en FCFA, par mobile money ou carte bancaire. Elle rejoint ensuite votre espace « Mes achats » : accès à vie, progression conservée, sur mobile comme sur ordinateur.</p></section>'
    +'<section class="dsec"><h2>Ce que vous apprendrez</h2><ul class="learn">'+learn+'</ul></section>'
    +'<section class="dsec curr"><h2>'+(r.fmt==='video'?'Programme':'Contenu')+'</h2><div class="currsum"><span>'+r.curriculum.length+' modules</span><span>'+r.lessonsTotal+' '+(r.fmt==='video'?'leçons':'sections')+'</span><span>'+r.meta+'</span></div>'+curr+'</section>'
    +'<section class="dsec"><h2>Votre formateur</h2><div class="authcard"><div class="big">'+a.initials+'</div><div><h3>'+a.name+'</h3><p class="role">'+a.role+' · '+a.city+'</p><div class="astats"><span><b>'+a.students.toLocaleString('fr-FR')+'</b> apprenants</span><span><b>'+a.resources+'</b> ressources</span></div></div><p class="bio">'+a.bio+'</p></div></section>';

  // ---- panneau achat ----
  const includes = r.includes.map(x=>'<li>'+CK+x+'</li>').join('');
  document.getElementById('buybox').innerHTML =
    '<div class="bcover"><div class="cover '+r.category.cover+'"><span class="type">'+r.format.label.toUpperCase()+' · '+r.meta.toUpperCase()+'</span>'+NK_glyph(r.format)
      +'<button class="fav" aria-pressed="false" aria-label="Ajouter aux favoris"><svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-9.8-9A5.6 5.6 0 0 1 12 6.3 5.6 5.6 0 0 1 21.8 12c-2.3 4.4-9.8 9-9.8 9z"/></svg></button></div></div>'
    +'<div class="bd"><div class="pr"><span class="price">'+P(r.price)+'<small>FCFA</small></span></div><p class="once">Paiement à l\u2019unité · accès à vie</p>'
    +'<button class="btn btn-p btn-lg" id="buy">Acheter maintenant</button><button class="btn btn-o" id="cart">Ajouter au panier</button>'
    +'<div class="guarantee"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>Accès immédiat après paiement</div>'
    +'<ul class="blist">'+includes+'</ul>'
    +'<div class="paynote"><span class="pp dark h22"><img src="assets/pay/orange-money.svg" alt="Orange Money"></span><span class="pp mtn"><img src="assets/pay/mtn.svg" alt="MTN MoMo"></span><span class="pp"><img src="assets/pay/wave.png" alt="Wave" class="h22"></span><span>+ carte bancaire</span></div></div>';

  // ---- ressources liées ----
  const related = NKAMVA.resources.filter(x=>x.cat===r.cat&&x.slug!==r.slug).slice(0,3);
  const rel = related.length?related:NKAMVA.resources.filter(x=>x.slug!==r.slug).slice(0,3);
  document.getElementById('relgrid').innerHTML = rel.map((x,i)=>rcCard(x,i)).join('');

  // ---- accordéon programme ----
  document.querySelector('.curr').addEventListener('click',e=>{
    const q=e.target.closest('.q');if(!q)return;
    const qa=q.parentElement,a=qa.querySelector('.a'),open=qa.classList.toggle('open');
    a.style.maxHeight=open?a.querySelector('.ain').scrollHeight+'px':0;
  });
  // ouvrir le 1er module (mesure après le reveal, sinon scrollHeight=0 pendant is-loading)
  function openFirst(){var f=document.querySelector('.curr .qa.open .a');if(f)f.style.maxHeight=f.querySelector('.ain').scrollHeight+'px';}
  if(document.body.classList.contains('is-ready'))openFirst();
  else{var iv=setInterval(function(){if(document.body.classList.contains('is-ready')){clearInterval(iv);openFirst();}},80);}

  // ---- achat ----
  document.getElementById('buybox').addEventListener('click',e=>{
    if(e.target.closest('#buy')){
      if(!window.NK_PURCHASES) return;
      NK_PURCHASES.openCheckout({
        title: r.title,
        subtitle: r.author.name+' · '+r.format.label,
        priceLabel: P(r.price)+' FCFA',
        successNote: 'La ressource rejoint votre espace « Mes ressources ».',
        onSuccess: function(){
          NK_PURCHASES.purchaseResource(r.slug);
          location.href = (window.NK_SPACE==='learner'?'Ma ressource.dc.html?r=':'Fiche ressource.dc.html?r=')+r.slug;
        }
      });
    }
    else if(e.target.closest('#cart'))window.toast&&toast('Ajouté au panier');
  });

  // ---- signaler ce contenu ----
  document.body.addEventListener('click', function(e){
    if (e.target.closest('#reportBtn')){
      var m = document.getElementById('report-modal');
      if (m) m.classList.add('open');
      return;
    }
    if (e.target.closest('[data-report-close]')){
      var m2 = document.getElementById('report-modal');
      if (m2) m2.classList.remove('open');
      return;
    }
    var send = e.target.closest('#reportSend');
    if (send){
      var reasonEl = document.querySelector('input[name="report-reason"]:checked');
      var reason = reasonEl ? reasonEl.value : 'Autre';
      var body = document.getElementById('report-modal-body');
      if (body) body.innerHTML = '<div style="text-align:center;padding:20px 0"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:40px;height:40px;color:var(--green);margin:0 auto 12px;display:block"><circle cx="12" cy="12" r="9"/><path d="m9 12 2 2 4-4"/></svg><b style="display:block;margin-bottom:4px">Signalement envoyé</b><p style="margin:0;color:var(--ink2);font-size:13.5px">Motif : '+reason+'. Notre équipe de modération l\u2019examinera sous peu.</p></div>';
    }
  });
})();
